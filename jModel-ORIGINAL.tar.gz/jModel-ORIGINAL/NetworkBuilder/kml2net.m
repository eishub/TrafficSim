function net = kml2net(model, netfile, rotate, detfile, demfile, starttime, duration, verbose, varargin)

% Reads a network, a detector and a demand file and combines the
% information into a jModel. The network file can be created in Google
% Earth while the detedector and demand file are generated using the
% Regiolab database.
%
% The network that is drawn in Google Earth is drawn as a set of road
% sections. This function may split sections upstream of merges to allow
% the upstream sections to be of equal length which allows them to be
% connected. In this way, drivers on both upstream sections can interact
% with each other to synchronize speed and align with a gap before the
% actual merge. The minimum total connected length upstream from the end of 
% the merge is 750m by default, unless an upstream split makes this 
% impossible. In the latter case the sections are connected directly after
% the split.
%
% This function will also check the reliability of detector data that is 
% requested for a source, destination or demand section. In case 99% (by
% default) or less of the measurements of a detector are reliable, a
% warning message is given.
%
% SYNTAX:
% net = kml2net(model, netfile, rotate, detfile, demfile, starttime, 
%                  duration, verbose)
% net = kml2net(..., minSyncDist, demReliability)
%
% INPUT:
% model     jModel object to add the network to.
%
% netfile   A Google Earth kml file that was created by saving a Google
%           Earth folder with a network defined in it. The network is
%           defined by a set of paths which can be draw in Google Earth.
%           For each section, a path should be drawn on the left edge of
%           the left-most lane. Each path should have a number (1, 2, ...)
%           as name. Each section can be given attributes in the comment
%           field of the path. Each attribute should be defined on a new
%           path in the comment field. The available attributes are:
% 
%           vlim:120    Speed limit of 120 km/h.
%           up:8        The section with number 8 is the upstream section.
%                       In case of a merge give two numbers with a comma in 
%                       between, e.g. "8,11" with 8 being the left section.
%           down:17     The section with number 17 is the downstream
%                       section. In case of a split give two numbers with a
%                       comma in between, e.g. "17,21" with 17 being the 
%                       left section.
%           detectors:  Comma seperated list of ids of detectors that are
%                       on the section. Per set of detectors at the same
%                       cross-section these should be given left to right.
%                       The order of cross-sections is not important. In
%                       case of a missing detector (e.g. at an onramp) give
%                       "0" as a place holder. Detectors can be shown in
%                       Google Earth with the kml file as generated with 
%                       'generateKml.m'.
%           origin:     Set of detectors from which the demand can be
%                       derived. A comma seperated list gives demand per
%                       lane (left to right). An equation in the form of 
%                       "263+264-282+283" will derive demand as the
%                       difference of the sum of all the detectors before  
%                       the "-" with the sum of all the detectors after the
%                        "-".
%           destination:Similar to origin, used for demand. A destination
%                       number is assigned to the lanes of the section.
%           demand:     Similar to origin, used for demand. Can be used to
%                       determine split fractions.
%           lanes:      Charachter sequence that defines the lanes and
%                       possibility of lane changes. Charachters 1, 4, 7,
%                       etc. define the lane types. Charachters 2, 5, 8,
%                       etc. define the possibility of lane changes to the
%                       right lane and charachters 3, 6, 9, etc. do the
%                       same for to the left lane. Use the following
%                       charachters:
%
%                       ":"     lane change possible
%                       "|"     lane change not possible
%                       "n"     normal lane
%                       "a"     lane without upstream lane (e.g. add)
%                       "s"     lane without downstream lane (e.g. subtract)
%                       "e"     lane without down and upstream lane (e.g. extra)
%                       "m"     merge taper
%                       "d"     diverge taper
%
%                       Example: "n::n|:m:|n" 
%                           Defines a four lane section with a merge taper.
%
%                       Example: "n|:n|:s"
%                           Simple onramp with lane change restriction from
%                           the left to the middle lane.
%
%                       If the correct lane types are assigned, this
%                       function can derive which lanes to connect to which
%                       lanes of an upstream or downstream section.
%
%           Only the applicable attributes have to be defined for a 
%           section. Other attributes will then be empty.
%           The Google Earth file and Google Earth map should have no other
%           contents.
%
% rotate    Degrees to rotate the network for a better screen-fit. Positive
%           angle rotates to the right.
%
% detfile   Text file with comma seperated detector info. This can be
%           created from the Regiolab database using the following SQL 
%           command:
%
%           SELECT key, roadnumber, position, distance, lanerank, 
%           location_wgs84, rws_bps_lanetypes.description_us FROM rws_bps 
%           JOIN rws_bps_lanetypes ON rws_bps.lanetype = rws_bps_lanetypes.type 
%           ORDER BY roadnumber, position, distance, direction, lanerank
%
%           Make sure to have no header or blank lines.
%
%           The resulting text file has lines that look like:
%
%               3191,16,R,33609,1,(4.643161,51.81159),Lane
%
%           'detfile' may also be empty. In that case detectors are
%           ignored.
%
% demfile   Text file with data for the demand. This can be created from
%           the Regiolab database using the following SQL command:
%
%           SELECT rws_bps.key, minute, reliable, flow, speed FROM 
%           rws_bps_detections INNER JOIN rws_bps ON 
%           rws_bps_detections.bpskey = rws_bps.key WHERE 
%           rws_bps.roadnumber = 16 AND rws_bps.distance > 33500 AND 
%           rws_bps.distance < 42000 AND minute >= '2009-05-28 15:00:00' 
%           AND minute < '2009-05-28 20:00:00' ORDER BY key, minute
%
%           Change the following information to match your requirements:
%
%           16
%               Replace with requested road number.
%
%           33500 & 42000
%               Define requested range. For the applicable range you can 
%               look at the detectors in Google Earth at the field
%               'distance'.
%
%           '2009-05-28 15:00:00' & '2009-05-28 20:00:00'
%               Replace with requested time/date range.
%
%           Make sure to have no header or blank lines.
%
%           The resulting text file has lines that look like:
%
%               3189,2009-05-28 15:00:00,1,8,98
%
%           'demfile' may also be empty. In that case demand is ignored.
%
% starttime Start time of the simultation. This should fall within the
%           range of the data file. Use a similar notation for the time,
%           e.g. '2009-05-28 16:00:00'. May be empty.
%
% duration  Number of minutes to run the scenario. The end of the run time
%           (after start time) should fall within the data range. May be
%           empty.
%
% minSyncDist       (optional) Minimum distance for linked sections 
%                   upstream of merge sections. Default is 750m.
%
% demReliability    (optional) Reliability below which a warning is given
%                   at a detector that is used for demand. Default is .99.
%
%
% OUTPUT:
% net       Structure with 1 or more fields per section number (#):
% 
%       section#        Array of jLane objects that was created for the
%                       section with given number.
%       demand#         Array of total demand (origin, destination or 
%                       demand field) per lane within the selected time 
%                       range of the section. This information can be used   
%                       to determine split fractions, route probabilities 
%                       and class probabilities. Note that generators were 
%                       created at the origin lanes, including the correct 
%                       demand. However, routes and classes and their 
%                       probabilities need to be added.
%       destination#    Destination number that the section received.
%       detector%.q/v   Actual detector data for each detector that was
%                       linked to a section in the network over the desired
%                       period. 'q' is the flow in veh/min and 'v' is the 
%                       speed in km/h. '%' is the detector id.
%
%       Note: the required section numbers # may sometimes become different 
%       as sections get split for synchronization upstream of merges. To
%       find out which sections get split, use the input argument 
%       verbose = true.

import microModel.*;

% create linked sections for synchronization upstream of merges over a
% distance of:
minSyncDist = 750;

% give warning if demand required at detector with reliability fraction 
% below:
demandReliability = .99;

% optional input
if ~isempty(varargin)
    minSyncDist = varargin{1};
    demandReliability = varargin{2};
end

doDemand = ~isempty(demfile);
doDetectors = ~isempty(detfile);

% read kml file
fid = fopen(netfile);
txt = textscan(fid, '%s', 'Delimiter', '\n');
txt = txt{1};
fclose(fid);

% loop text and find tags
minLat = Inf;
maxLong = -Inf;
inPlaceMark = false;
inDescription = false;
inCoordinates = false;
for i = 1:length(txt)
    if strfind(txt{i}, '<Placemark>')
        inPlaceMark = true;
    elseif strfind(txt{i}, '</Placemark>')
        inPlaceMark = false;
    end
    if inPlaceMark
        if strfind(txt{i}, '<name>')
            i1 = strfind(txt{i}, '<name>');
            i2 = strfind(txt{i}, '</name>');
            section = str2double(txt{i}(i1+6:i2-1));
        end
        if strfind(txt{i}, '<description>')
            inDescription = true;
            txt{i} = strrep(txt{i}, '<description>', '');
        end
        if strfind(txt{i}, '<coordinates>')
            inCoordinates = true;
        end
        if inDescription
            outOnNext = false;
            if strfind(txt{i}, '</description>')
                txt{i} = strrep(txt{i}, '</description>', '');
                outOnNext = true;
            end
            txt{i} = strtrim(txt{i});
            colon = strfind(txt{i}, ':');
            lab = txt{i}(1:colon(1)-1);
            val = txt{i}(colon(1)+1:end);
            switch lab
                case {'vlim', 'up', 'down', 'detectors'}
                    sections(section).(lab) = str2num(val);
                case {'lanes', 'destination', 'origin', 'demand'}
                    sections(section).(lab) = val;
            end
            if outOnNext
                inDescription = false;
            end
        elseif inCoordinates
            if strfind(txt{i}, '<coordinates>')
                % nothing for first line
            elseif strfind(txt{i}, '</coordinates>')
                inCoordinates = false;
            else
                nums = str2num(txt{i});
                sections(section).lat = nums(1:3:end);
                sections(section).long = nums(2:3:end);
                minLat = min(minLat, min(sections(section).lat));
                maxLong = max(maxLong, max(sections(section).long));
            end
        end
    end
end

% add a section with all the possible fields, and remove it again
% this prevents 'field not found' errors
n = length(sections)+1;
sections(n).vlim = [];
sections(n).up = [];
sections(n).down = [];
sections(n).detectors = [];
sections(n).lanes = [];
sections(n).destination = [];
sections(n).origin = [];
sections(n).demand = [];
sections(n).sibling = [];
sections(n) = [];

% calculate distances from base point
for i = 1:length(sections)
    for j = 1:length(sections(i).lat)
        dx = dLat(minLat, sections(i).lat(j), sections(i).long(j), maxLong);
        dy = dLong(sections(i).long(j), maxLong);
        r = sqrt(dx^2+dy^2);
        ang = atan(dy/dx) + rotate*pi/180;
        y = sin(ang)*r;
        x = cos(ang)*r;
        sections(i).x(j) = x;
        sections(i).y(j) = y;
    end
end

% split for synchronization
n = length(sections);
connects = [];
for i = 1:n
    % split in case of merge (= section with two upstream sections)
    if length(sections(i).up)==2
        x0 = 0; % length upto current sections
        for j = 1:length(sections(i).x)-1
            dx = sections(i).x(j+1) - sections(i).x(j);
            dy = sections(i).y(j+1) - sections(i).y(j);
            x0 = x0 + sqrt(dx^2 + dy^2);
        end
        % loop while having a single section left and right (no split upstream)
        nl = sections(i).up(1);
        nr = sections(i).up(2);
        while x0 < minSyncDist && length(nl)==1 && length(nr)==1
            % get lengths of current left and right sections
            xleft = 0;
            for j = 1:length(sections(nl).x)-1
                dx = sections(nl).x(j+1) - sections(nl).x(j);
                dy = sections(nl).y(j+1) - sections(nl).y(j);
                xleft = xleft + sqrt(dx^2 + dy^2);
            end
            xright = 0;
            for j = 1:length(sections(nr).x)-1
                dx = sections(nr).x(j+1) - sections(nr).x(j);
                dy = sections(nr).y(j+1) - sections(nr).y(j);
                xright = xright + sqrt(dx^2 + dy^2);
            end
            x0 = x0 + min(xleft, xright);
            % get the longer section, and how how much to split from it
            if xleft<xright
                split = nr;
                xSplit = xright-xleft;
            else
                split = nl;
                xSplit = xleft-xright;
            end
            % create a new section
            nn = length(sections)+1;
            if verbose
                disp(['Section ' num2str(split) ' was split with new upstream section ' num2str(nn) '.'])
            end
            sections(nn) = sections(split); % copy
            % update new section info
            sections(nn).detectors = []; % without the detectors
            sections(nn).lanes = strrep(sections(nn).lanes, 's', 'n'); % new lane has a downstream lane
            sections(nn).lanes = strrep(sections(nn).lanes, 'e', 'a'); % new lane has a downstream lane
            sections(nn).down(:) = split;
            % update info of section upstream of new section
            for j = 1:length(sections(nn).up)
                sections(sections(nn).up(j)).down( sections(sections(nn).up(j)).down==split ) = nn;
            end
            % update old section info
            sections(split).origin = []; % upstream lane now has the generator(s)
            sections(split).lanes = strrep(sections(split).lanes, 'e', 's'); % old lane has an upstream lane
            sections(split).up(1:max(1,length(sections(split).up))) = nn;
            sections(split).sibling = nn; % used for detector localisation
            % split the curvature coordinates
            x = sections(split).x;
            y = sections(split).y;
            xCumul = 0;
            cut = false;
            j = 1;
            while ~cut
                % current sub section length
                dx = x(j+1)-x(j);
                dy = y(j+1)-y(j);
                dl = sqrt(dx^2 + dy^2);
                % split if split length is reached in this sub section
                if xCumul+dl > xSplit
                    % fraction within sub section
                    f = (xSplit-xCumul) / dl;
                    % split point on sub section
                    xCut = (1-f)*x(j) + f*x(j+1);
                    yCut = (1-f)*y(j) + f*y(j+1);
                    % set coordinates of new and split sections
                    sections(nn).x = [x(1:j) xCut];
                    sections(nn).y = [y(1:j) yCut];
                    sections(split).x = [xCut x(j+1:end)];
                    sections(split).y = [yCut y(j+1:end)];
                    cut = true;
                end
                xCumul = xCumul+dl;
                j = j+1;
            end
            % remeber to connect the two upsteam sections later
            connects(end+1,1:2) = [nl nr];
            % move further
            nl = sections(nl).up;
            nr = sections(nr).up;
        end
    end
end

if doDemand
    % read demand file
    fid = fopen(demfile);
    txt = textscan(fid, '%f%f-%f-%f %f:%f:%f%f%f%f', 'Delimiter', ',');
    fclose(fid);
    n = size(txt{1},1);
    t = zeros(n,1);
    for i = 1:n
        % this is much faster than reading the date as string and using datenum
        t(i) = datenum([txt{2}(i) txt{3}(i) txt{4}(i) txt{5}(i) txt{6}(i) txt{7}(i)]);
    end
    t1 = datenum(starttime, 'yyyy-mm-dd HH:MM:SS');
    t2 = t1+duration/(24*60);
    these = t>=t1 & t<t2;
    ids = txt{1}(these);
    rels = txt{8}(these);
    qs = txt{9}(these);
    vs = txt{10}(these);
    these = vs>250;
    vs(these) = NaN; % speed not reliable
end

% create the lanes and connect them in the lateral direction
id = 1; % lane id counter
destination = 0; % destination number counter
uniform = javaMethod('valueOf', 'microModel.jGenerator$distribution', 'UNIFORM');
for i = 1:length(sections)
    % number of lanes
    n = 1+(length(sections(i).lanes)-1)/3;
    % set triggers for creating generators at origins, setting destination
    % number at destinations, and retrieving demand at a demand section.
    demStr = '';
    isDestination = false;
    if ~isempty(sections(i).destination)
        destination = destination+1;
        isDestination = true;
        demStr = sections(i).destination;
    end
    isOrigin = false;
    if ~isempty(sections(i).origin)
        isOrigin = true;
        demStr = sections(i).origin;
    end
    if ~isempty(sections(i).demand)
        demStr = sections(i).demand;
    end
    % in case of destination, origin or demand, derive demand
    if ~isempty(demStr)
        if strfind(demStr, '-')
            % equational form of demand
            ind = strfind(demStr, '-');
            adds = demStr(1:ind-1); % detectors that need to be added
            subs = demStr(ind+1:end); % detectors that need to be subtracted
            totDemand = 0;
            while ~isempty(adds)
                [detId adds] = strtok(adds, '+');
                detId = str2double(detId);
                these = ids==detId;
                rel = rels(these);
                if sum(rel)/length(rel)<demandReliability
                    disp(['WARNING: demand required from detector ' num2str(detId) ...
                        ' but only ' num2str(100*sum(rel)/length(rel)) '% of data is reliable.'])
                end
                totDemand = totDemand+qs(these);
            end
            while ~isempty(subs)
                [detId subs] = strtok(subs, '+');
                detId = str2double(detId);
                these = ids==detId;
                rel = rels(these);
                if sum(rel)/length(rel)<demandReliability
                    disp(['WARNING: demand required from detector ' num2str(detId) ...
                        ' but only ' num2str(100*sum(rel)/length(rel)) '% of data is reliable.'])
                end
                totDemand = totDemand-qs(these);
            end
            % shift negative demand, subtract from later positive demand
            totDemand = positifyDemand(totDemand);
            totDemand = totDemand/n; % per lane
            totDemand = repmat(totDemand, 1, n); % repeated per lane
        else
            % demand per individual lane
            totDemand = [];
            dests = demStr;
            while ~isempty(dests)
                [detId dests] = strtok(dests, ',');
                detId = str2double(detId);
                these = ids==detId;
                rel = rels(these);
                if sum(rel)/length(rel)<demandReliability
                    disp(['WARNING: demand required from detector ' num2str(detId) ...
                        ' but only ' num2str(100*sum(rel)/length(rel)) '% of data is reliable.'])
                end
                totDemand = [totDemand qs(these)];
            end
        end
        net.(['demand' num2str(i)]) = totDemand;
    end
    % in case of tapers, lateral positions are not simply 3.5m x #lane
    merged = false;
    diverged = false;
    % loop upto the number of lanes
    for j = 1:n
        % derive merge taper or diverge taper triggers
        isTaper = false;
        if strcmp(sections(i).lanes((j-1)*3+1), 'm')
            merged = true;
            isTaper = true;
        elseif strcmp(sections(i).lanes((j-1)*3+1), 'd')
            diverged = true;
            isTaper = true;
        end
        % Calculate the points as being some distance to the right from the
        % defined line, which was drawn at the left-edge of the left lane.
        % Start with 1.75m and add 3.5m for the next lanes. Also keep the
        % lateral influence of tapers into account.
        [x y] = rightParallel(-1.75+j*3.5, sections(i).x, sections(i).y, merged, diverged);
        % create the lane object
        model.network(id) = jLane(model, x, y, id);
        model.network(id).vLim = sections(i).vlim;
        % add lane to output
        net.(['section' num2str(i)])(j) = model.network(id);
        % set taper pointer to self in case of taper
        if isTaper
            model.network(id).taper = model.network(id);
        end
        % set destination
        if isDestination
            model.network(id).destination = destination;
            net.(['destination' num2str(i)])(j) = destination;
        end
        % create generator at origin
        if isOrigin
            jGenerator(model.network(id), uniform);
            % set the demand that was determined
            model.network(id).generator.setDemand([(0:60:60*(duration-1))' totDemand(:,j)*60]);
            model.network(id).generator.interpDemand = false;
        end
        % set lane object in section array
        sections(i).jLanes(j) = model.network(id);
        % increase lane id counter
        id = id+1;
        % connect with the left lane (so starting from the second lane)
        if j>1
            goright = strcmp(sections(i).lanes((j-2)*3+2), ':');
            goleft = strcmp(sections(i).lanes((j-2)*3+3), ':');
            sections(i).jLanes(j-1).connectLat(goright, sections(i).jLanes(j), goleft);
        end
    end
end
% connect the remebered sections upstream of merges, without lane change
% possibilities
for i = 1:size(connects,1)
    % connect right-most with left-most lane of left and right sections
    sections(connects(i,1)).jLanes(end).connectLat(false, sections(connects(i,2)).jLanes(1), false);
end

if doDetectors
    % add detectors
    detids = [];
    longs = [];
    lats = [];
    % loop text and get id / lat / long
    fid = fopen(detfile);
    txt = textscan(fid, '%s', 'Delimiter', '\n');
    txt = txt{1};
    fclose(fid);
    txt = fixDetectorErrors(txt);
    for i=1:length(txt)
        commas = strfind(txt{i}, ',');
        detids = [detids str2double(txt{i}(1:commas(1)-1))];
        open = strfind(txt{i}, '(');
        clos = strfind(txt{i}, ')');
        commas(commas<open) = [];
        commas(commas>clos) = [];
        lats = [lats str2double(txt{i}(open+1:commas-1))];
        longs = [longs str2double(txt{i}(commas+1:clos-1))];
    end
    % loop sections
    for i=1:length(sections)
        % loop detectors at the section
        for j=1:length(sections(i).detectors)
            % set data for closest location on lane search
            cursection = i;
            atsection = i;
            atx = 0;
            mind = Inf;
            xCumul = 0;
            id = sections(i).detectors(j);
            ind = find(detids==id);
            n = length(sections(cursection).jLanes);
            % j2 is lane number, at a three lane section: 1,2,3,1,2,3,1,2, etc.
            j2 = j - n*floor((j-1)./n);
            while id>0 && ~isempty(cursection) % id = 0 means skip one lane
                % loop over the sub sections of the appropiate lane
                for k=1:length(sections(cursection).jLanes(j2).x)-1
                    % get coordinates of detectors
                    dx = dLat(minLat, lats(ind), longs(ind), maxLong);
                    dy = dLong(longs(ind), maxLong);
                    r = sqrt(dx^2+dy^2);
                    ang = atan(dy/dx) + rotate*pi/180;
                    y = sin(ang)*r;
                    x = cos(ang)*r;
                    % length and heading of current sub section
                    dx = sections(cursection).jLanes(j2).x(k+1)-sections(cursection).jLanes(j2).x(k);
                    dy = sections(cursection).jLanes(j2).y(k+1)-sections(cursection).jLanes(j2).y(k);
                    len = sqrt(dx^2 + dy^2); % length of this section
                    % normalized vector of sub section heading
                    vec1 = [dx, dy] / len; 
                    % vector from start of sub-section to detector
                    vec2 = [x-sections(cursection).jLanes(j2).x(k), y-sections(cursection).jLanes(j2).y(k)];
                    % length of vec2
                    rvec2 = sqrt(vec2(1)^2 + vec2(2)^2);
                    % angle between section and line towards detector with dot product
                    ang = acos(dot(vec1, vec2/rvec2)); 
                    % fraction on sub section where point is found closest to detector
                    f = rvec2 * cos(ang) / len;
                    % limit to being on the sub section
                    if f>1; f=1; end
                    if f<0; f=0; end
                    % get coordinates of that point
                    xd = (1-f)*sections(cursection).jLanes(j2).x(k) + f*sections(cursection).jLanes(j2).x(k+1);
                    yd = (1-f)*sections(cursection).jLanes(j2).y(k) + f*sections(cursection).jLanes(j2).y(k+1);
                    % get distance from that point to the detector
                    d = sqrt((x-xd)^2 + (y-yd)^2);
                    % if shorter distance than previous section, use this
                    % location for the detector
                    if d<mind
                        atx = xCumul + f*len;
                        atsection = cursection;
                        mind = d;
                    end
                    xCumul = xCumul + len;
                end
                % the sibling was part of the same section in the kml file, but
                % was split from that section for the synchronization upstream
                % of merges, detectors might be located at the sibling.
                xCumul = 0;
                cursection = sections(cursection).sibling;
            end
            % create the detector at the nearest position on the lane
            if (id>0)
                jDetector(sections(atsection).jLanes(j2), atx, 60, id);
                these = ids==id;
                net.(['detector' num2str(id)]).q = qs(these);
                net.(['detector' num2str(id)]).v = vs(these);
            end
        end
    end
end

% find lanes which may connect to up/downstream lanes
for i = 1:length(sections)
    str = sections(i).lanes;
    str = strrep(str, ':', '');
    str = strrep(str, '|', '');
    sections(i).lanes2up = find(str=='n' | str=='s' | str=='m');
    sections(i).lanes2down = find(str=='n' | str=='a' | str=='d');
end

% find appropiate sections for each lane (e.g. [1, 15] ==> [1, 1, 15] for an 2 lane highway offramp)
for i = 1:length(sections)
    if ~isempty(sections(i).down)
        down = [];
        % loop downstream sections
        for j = 1:length(sections(i).down)
            % number of lanes to connect is not more than in the current section
            n = min(length(sections(sections(i).down(j)).lanes2up), length(sections(i).jLanes));
            % loop downstream lanes that have an upstream lane
            for k = 1:n
                down(end+1) = sections(i).down(j);
            end
        end
        sections(i).downperlane = down;
    end
    if ~isempty(sections(i).up)
        up = [];
        % loop upstream sections
        for j = 1:length(sections(i).up)
            % number of lanes to connect is not more than in the current section
            n = min(length(sections(sections(i).up(j)).lanes2down), length(sections(i).jLanes));
            % loop upstream lanes that have a downstream lane
            for k = 1:n
                up(end+1) = sections(i).up(j);
            end
        end
        sections(i).upperlane = up;
    end
end

% connect the lanes in the longitudinal direction
for i = 1:length(sections)
    if ~isempty(sections(i).down)
        % loop lanes with downstream lane
        for j = 1:length(sections(i).lanes2down)
            % get the lane object
            this = sections(i).jLanes(sections(i).lanes2down(j));
            % downstream section
            downsection = sections(i).downperlane(j);
            % nth lane towards the current downstream section
            nthlane = sum(sections(i).downperlane(1:j)==downsection);
            % nth index of lanes in downstream section with upstream lane
            avalIndex = find(cumsum(sections(downsection).upperlane==i)==nthlane, 1, 'first');
            % get the lane number of the nth lane with upstream lane
            allIndex = sections(downsection).lanes2up(avalIndex);
            % get the downstream lane object
            down = sections(downsection).jLanes(allIndex);
            % connect them
            down.connectLong(this);
            % match curvature coordinates to exactly the same coordinate,
            % the coordinates of the section with more lanes is used,
            % otherwise that section may be adjusted to two other sections
            % resulting in the lanes not being nicely 3.5m apart.
            if length(sections(i).jLanes) >= length(sections(downsection).jLanes)
                useDownCoord = false;
            else
                useDownCoord = true;
            end
            if useDownCoord
                this.x(end) = down.x(1);
                this.y(end) = down.y(1);
                this.calculateLength; % recalculate length, is slightly different which may produce errors
            else
                down.x(1) = this.x(end);
                down.y(1) = this.y(end);
                down.calculateLength; % recalculate length, is slightly different which may produce errors
            end
        end
    end
end

% Function to calculate the distance between two lateral coordinates. The
% longitude coordinates are required to determine the radius of a
% horizontal slice of the earth.
function d = dLat(lat1, lat2, long1, long2)
long = (long1+long2)/2;
r = rAtLong(long);
r = rForLat(long, r);
dAng = abs(lat1 - lat2);
d = 2*r*pi * dAng/360;

% Function to calculate the distance between two longitude coordinates.
function d = dLong(long1, long2)
long = (long1+long2)/2;
r = rAtLong(long);
dAng = abs(long1 - long2);
d = 2*r*pi * dAng/360;

% Radius of the earth at given longitude, as the earth is slightly oval.
function r = rAtLong(long)
a = 6378137; % radius at equator
b = 6356752.3; % radius at poles
r = sqrt( ( (a^2*cos(long))^2 + (b^2*sin(long))^2 ) / ( (a*cos(long))^2 + (b*sin(long))^2 ) );

% Radius of horizontal slice at given longitude, for which the oval radius 
% 'r' was calculated.
function r = rForLat(long, r)
r = r*cos(long*2*pi/360);

% Function to find the coordinates of a line that is parallel to the input
% line at a distance 'd'. In case a merge or diverge taper was encountered,
% the distance 'd' is adjusted to account for the taper shape.
function [xOut yOut] = rightParallel(d, x, y, merged, diverged)
% we need the lane length to linearly interpolate the width over the length
% of taper sections
if merged || diverged
    laneLength = 0;
    for i = 1:length(x)-1
        dx = x(i+1)-x(i);
        dy = y(i+1)-y(i);
        laneLength = laneLength + sqrt(dx^2+dy^2);
    end
end
% initialize new line
n = length(x);
xOut = zeros(n,1);
yOut = zeros(n,1);
% first point
if diverged
    f = -3.5;
else
    f = 0;
end
% intersect two adjacent 2-subsection lines for the middle point
% extend the first section upstream to use this function
[xOut(1) yOut(1)] = intersectLines(d+f, [x(1)-(x(2)-x(1)) x(1) x(2)], [y(1)-(y(2)-y(1)) y(1) y(2)]);
dx = x(2)-x(1);
dy = y(2)-y(1);
xCumul = sqrt(dx^2+dy^2);
% intermediate points
for i=2:n-1
    % update width adjustment for tapers
    if merged
        f = -3.5 * xCumul/laneLength;
    elseif diverged
        f = -3.5 * (laneLength-xCumul)/laneLength;
    else
        f = 0;
    end 
    % intersect two adjacent 2-subsection lines for the middle point
    [xOut(i) yOut(i)] = intersectLines(d+f, [x(i-1) x(i) x(i+1)], [y(i-1) y(i) y(i+1)]);
    % update length along section (for tapers)
    dx = x(i+1)-x(i);
    dy = y(i+1)-y(i);
    xCumul = xCumul + sqrt(dx^2+dy^2);
end
% last point
if merged
    f = -3.5;
else
    f = 0;
end
% intersect two adjacent 2-subsection lines for the middle point
[xOut(n) yOut(n)] = intersectLines(d+f, [x(n-1) x(n) x(n)+(x(n)-x(n-1))], [y(n-1) y(n) y(n)+(y(n)-y(n-1))]);

% Function to move the two subsections right with a distance d, and to find
% the intersection point of those lines.
function [x y] = intersectLines(d, xs, ys)
% get headings
dx1 = xs(2)-xs(1);
dx2 = xs(3)-xs(2);
dy1 = ys(2)-ys(1);
dy2 = ys(3)-ys(2);

% normalization
f1 = 1/sqrt(dx1^2 + dy1^2);
f2 = 1/sqrt(dx2^2 + dy2^2);

% get right adjacent points
xRight1  = xs(1)-dy1*f1*d;
xRight2a = xs(2)-dy1*f1*d;
xRight2b = xs(2)-dy2*f2*d;
xRight3  = xs(3)-dy2*f2*d;
yRight1  = ys(1)+dx1*f1*d;
yRight2a = ys(2)+dx1*f1*d;
yRight2b = ys(2)+dx2*f2*d;
yRight3  = ys(3)+dx2*f2*d;

% intersect the two lines
a1 = (yRight2a-yRight1)/(xRight2a-xRight1);
b1 = yRight1 - xRight1*a1;
a2 = (yRight3-yRight2b)/(xRight3-xRight2b);
b2 = yRight2b - xRight2b*a2;
if abs(a1-a2)<0.001
    % basically one straight line
    x = xRight2a;
    y = yRight2a;
else
    x = -(b1-b2)/(a1-a2);
    y = a1*x+b1;
end

% Make sure demand is positive by subtracting negative demand from later
% positive demand, and setting the negative demand to zero. Example:
%
% [3 2 -1 7 -3 -2 4 7] becomes [3 2 0 6 0 0 0 6];
%
function totDemand = positifyDemand(totDemand)
net = 0;
for i = 1:length(totDemand)
    % keep track of net cumulative value
    net = net+totDemand(i);
    if net<0
        % if negative, set to zero and remember net for next minute
        totDemand(i) = 0;
    else
        % if positive, set the demand, reset the cumulative net value
        totDemand(i) = net;
        net = 0;
    end
end