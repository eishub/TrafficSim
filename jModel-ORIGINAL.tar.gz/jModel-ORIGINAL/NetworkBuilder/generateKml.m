function generateKml(detfile)

% This function creates a kml file from a text file with detector
% information. The file can be created with the below SQL command. Make
% sure you create a comma-separated file without header lines or blank
% lines at the bottom.
%
% SELECT key, roadnumber, position, distance, lanerank, location_wgs84, 
% rws_bps_lanetypes.description_us FROM rws_bps JOIN rws_bps_lanetypes ON 
% rws_bps.lanetype = rws_bps_lanetypes.type ORDER BY roadnumber, position, 
% distance, direction, lanerank

% read file
fid = fopen(detfile);
txt = textscan(fid, '%s', 'Delimiter', '\n');
txt = txt{1};
fclose(fid);

% fix known database errors
txt = fixDetectorErrors(txt);

% initialize data for loop
curroad = 0;
curpos = '';
ids = [];
curlong = 0;
curlat = 0;

% build file
out = startKml;
part = {};
progress = -1;
for i = 1:length(txt)
    if floor(100*(i/length(txt)))>progress
        progress = floor(100*(i/length(txt)));
        disp(['Progress at ' num2str(progress) '%'])
    end
    [id, road, pos, dist, rank, long, lat, type] = readLine(txt{i});
    partadded = false;
    if curroad && road>curroad
        out = [out; part; endSide; endRoad; startRoad(road); startSide(pos)];
        partadded = true;
        curroad = road;
        curpos = pos;
    elseif ~curroad
        out = [out; part; startRoad(road); startSide(pos)];
        partadded = true;
        curroad = road;
        curpos = pos;
    elseif ~strcmp(pos, curpos)
        out = [out; part; endSide; startSide(pos)];
        partadded = true;
        curpos = pos;
    end
    if long==curlong && lat==curlat
        % same location, update temporary part
        ids = [ids id];
        ranks = [ranks rank];
        types = [types {type}];
        part = item(long, lat, dist, ids, ranks, road, pos, types);
    else
        % new location
        % add previous part
        if ~partadded
            out = [out; part];
        end
        % create new temporary part
        ids = id;
        ranks = rank;
        types = {type};
        part = item(long, lat, dist, ids, ranks, road, pos, types);
        % set new location
        curlong = long;
        curlat = lat;
    end 
end
% add last temporary part
out = [out; part; endSide; endRoad];
% add final part
out = [out; endKml];

% write file
fid = fopen('Detectors Regiolab.kml', 'w');
fprintf(fid, '%s\n', out{:});
fclose(fid);

function [id, road, pos, dist, rank, long, lat, type] = readLine(line)
line = strrep(line, '(', '');
line = strrep(line, ')', '');
[id line] = strtok(line, ','); id = str2num(id);
[road line] = strtok(line, ','); road = str2num(road);
[pos line] = strtok(line, ',');
[dist line] = strtok(line, ','); dist = str2num(dist);
[rank line] = strtok(line, ','); rank = str2num(rank);
[long line] = strtok(line, ','); long = str2num(long);
[lat line] = strtok(line, ','); lat = str2num(lat);
[type line] = strtok(line, ',');

function part = startRoad(roadnumber)
part = {
    '        <Folder>';
    ['            <name>A' num2str(roadnumber) '</name>']};

function part = endRoad
part = {
    '        </Folder>'};

function part = startSide(side)
part = {
    '            <Folder>';
    ['                <name>' side '</name>']};

function part = endSide
part = {
    '            </Folder>'};

function part = item(long, lat, dist, ids, ranks, road, pos, types)
tps = '';
for i=1:length(types)
    tps = [tps types{i} '/'];
end
tps(end) = [];
part = {
    '                <Placemark>';
    ['                    <name>' strrep([sprintf('%i/', ids) '@'], '/@', '') '</name>'];
    ['                    <description>road: A' num2str(road)];
    ['position: ' pos];
    ['distance: ' num2str(dist)];
    ['ids: ' strrep([sprintf('%i/', ids) '@'], '/@', '')];
    ['ranks: ' strrep([sprintf('%i/', ranks) '@'], '/@', '')];
    ['types: ' tps  '</description>'];
    '                    <LookAt>';
    ['                        <longitude>' num2str(long) '</longitude>'];
    ['                        <latitude>' num2str(lat) '</latitude>'];
    '                        <altitude>0</altitude>';
    '                        <heading>0</heading>';
    '                        <tilt>0</tilt>';
    '                        <range>200</range>';
    '                        <altitudeMode>relativeToGround</altitudeMode>';
    '                        <gx:altitudeMode>relativeToSeaFloor</gx:altitudeMode>';
    '                    </LookAt>';
    '                    <styleUrl>#sn_square</styleUrl>';
    '                    <Point>';
    ['                        <coordinates>' num2str(long) ',' num2str(lat) ',0</coordinates>'];
    '                    </Point>';
    '                </Placemark>'};

function part = startKml
part = {
    '<?xml version="1.0" encoding="UTF-8"?>';
    '<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2" xmlns:kml="http://www.opengis.net/kml/2.2" xmlns:atom="http://www.w3.org/2005/Atom">';
    '<Document>';
    '    <name>Detectors Regiolab.kml</name>';
    '    <Style id="sn_square">';
    '        <IconStyle>';
    '            <scale>0.6</scale>';
    '            <Icon>';
    '                <href>http://maps.google.com/mapfiles/kml/shapes/square.png</href>';
    '            </Icon>';
    '            <hotSpot x="32" y="1" xunits="pixels" yunits="pixels"/>';
    '        </IconStyle>';
    '        <LabelStyle>';
    '            <scale>0.6</scale>';
    '        </LabelStyle>';
    '    </Style>';
    '    <Folder>';
    '        <name>Detectors Regiolab</name>';
    '        <open>1</open>'};

function part = endKml
part = {
    '    </Folder>';
    '</Document>';
    '</kml>'};