function detectorsSQL

% Performs the default SQL command to derive the detector information.

query = ['SELECT key, roadnumber, position, distance, lanerank, ', ...
    'location_wgs84, rws_bps_lanetypes.description_us FROM rws_bps ', ...
    'JOIN rws_bps_lanetypes ON rws_bps.lanetype = rws_bps_lanetypes.type ', ...
    'ORDER BY roadnumber, position, distance, direction, lanerank'];

SQL(query);