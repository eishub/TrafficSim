package microModel;

/**
 * Storable trajectory data from a <tt>jTrajectory</tt> object.
 */
public class jTrajectoryData implements java.io.Serializable {

    /** Time [s] array. */
    public double[] t;
    
    /** Position [m] array. */
    public double[] x;
    
    /** Speed [m/s] array. */
    public double[] v;
    
    /** Acceleration [m/s^2] array. */
    public double[] a;
    
    /** Lane ID array. */
    public int[] lane;
    
    /** Lane change progress [0...1] array. */
    public double[] lcProgress;
    
    /** Vehicle class ID. */
    public int classID;

    /**
     * Constructs a data object from the given <tt>jTrajectory</tt>.
     * @param trajectory Detector of which the data needs to be stored.
     */
    public jTrajectoryData(jTrajectory trajectory) {
        t = trajectory.t();
        x = trajectory.x();
        v = trajectory.v();
        a = trajectory.a();
        lane = trajectory.laneID();
        lcProgress = trajectory.lcProgress();
        classID = trajectory.vehicle.classID;
    }
}