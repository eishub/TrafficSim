package microModel;

/**
 * Trajectory of a vehicle. This is basically an array of <tt>jFCD</tt> objects.
 */
public class jTrajectory {

    /** Array of <tt>jFCD</tt> objects. */
    protected java.util.ArrayList<jFCD> FCD = new java.util.ArrayList<jFCD>();
    
    /** Vehicle of this trajectory. */
    public jVehicle vehicle;
    
    /** Time when last snap-shot of vehicle was stored. */
    protected double tData;

    /**
     * Constructor linking this trajectory to a vehicle.
     * @param veh Vehicle of trajectory.
     */
    public jTrajectory(jVehicle veh) {
        vehicle = veh;
        tData = vehicle.model.t-vehicle.model.settings.getDouble("trajectoryPeriod");
    }

    /**
     * Appends current data of vehicle to an internal array at appripiate interval.
     */
    public void append() {
        if (vehicle.model.settings.getBoolean("storeTrajectoryData") && 
                vehicle.model.t-tData >= vehicle.model.settings.getDouble("trajectoryPeriod")) {
            // create new jFCD and add to vector
            FCD.add(new jFCD(vehicle));
            // update last sampling time
            tData = tData + vehicle.model.settings.getDouble("trajectoryPeriod");
        }
    }
    
    /**
     * Composes time array.
     * @return Array of time [s].
     */
    public double[] t() {
        double[] t = new double[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            t[i] = FCD.get(i).t;
        }
        return t;
    }

    /**
     * Composes position array.
     * @return x Array of positions [m].
     */
    public double[] x() {
        double[] x = new double[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            x[i] = FCD.get(i).x;
        }
        return x;
    }

    /**
     * Composes speed array.
     * @return v Array of speeds [m/s].
     */
    public double[] v() {
        double[] v = new double[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            v[i] = FCD.get(i).v;
        }
        return v;
    }

    /**
     * Composes acceleration array.
     * @return a Array of accelerations [m/s^2].
     */
    public double[] a() {
        double[] a = new double[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            a[i] = FCD.get(i).a;
        }
        return a;
    }

    /**
     * Composes lane change progress array.
     * @return lcProgress Array of lane change progress [0...1].
     */
    public double[] lcProgress() {
        double[] lcProgress = new double[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            lcProgress[i] = FCD.get(i).lcProgress;
        }
        return lcProgress;
    }

    /**
     * Composes lane array.
     * @return lane Array of lane IDs.
     */
    public int[] laneID() {
        int[] lane = new int[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            lane[i] = FCD.get(i).lane.id;
        }
        return lane;
    }

    /**
     * Composes lane array.
     * @return lane Array of <tt>jLane</tt> objects.
     */
    public jLane[] lane() {
        jLane[] lane = new jLane[FCD.size()];
        for (int i=0; i<FCD.size(); i++) {
            lane[i] = FCD.get(i).lane;
        }
        return lane;
    }
}