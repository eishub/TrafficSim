package microModel;

/**
 * Default wrapper for a vehicle. It contains a driver and possibly an OBU.
 */
public class jVehicle extends jMovable {

    /** OBU within the vehicle, may be <tt>null</tt>. */
    public jOBU OBU;
    
    /** Driver of the vehicle. */
    public jDriver driver;
    
    /** Current lateral speed in 'amount of lane per time step' [0...1]. */
    public double dy;
    
    /** Total progress of a lane change in 'amount of lane' [0...1]. */
    public double lcProgress;
    
    /** Lane change direction. */
    public jModel.latDirection lcDirection;
    
    /** Temporary lane change vehicle, if any. */
    public jLcVehicle lcVehicle;
    
    /** Maximum vehicle speed [km/h]. */
    public double vMax;
    
    /** Maximum vehicle deceleration (a value below 0) [m/s^2]. */
    public double aMin;
    
    /** Route of the vehicle (or driver). */
    public jRoute route;
    
    /** Vehicle trajectory. */
    public jTrajectory trajectory;
    
    /** Vehicle class ID. */
    public int classID;

    /** 
     * Constructor connecting the vehicle with the main model. 
     * @param model Main model.
     */
    public jVehicle(jModel model) {
        super(model);
    }

    /**
     * Moves the vehicle in longitudinal and lateral direction based on 
     * <tt>a</tt> and <tt>dy</tt>.
     */
    public void move() {
        // lateral
        lcProgress = lcProgress+dy;
        // longitudinal
        double dt = model.dt;
        double dx = dt*v + .5*a*dt*dt;
        dx = dx >= 0 ? dx : 0;
        v = v+dt*a;
        v = v >= 0 ? v : 0;
        translate(dx);
        setXY();
    }

    /**
     * Function to translate a distance, moving onto downstream lanes as needed.
     * If a destination is reached the vehicle is deleted.
     * @param dx Distance [m] to translate.
     */
    public void translate(double dx) {
        // Check whether an RSU is passed
        for (int i=0; i<lane.RSUcount(); i++) {
            if (lane.getRSU(i).x>x && lane.getRSU(i).x<=x+dx && lane.getRSU(i).passable) {
                lane.getRSU(i).pass(this);
            }
        }
        // Move movable downstream
        x = x+dx;
        justExceededLane = false;
        if (x > lane.l) {
            justExceededLane = true;
            if (lane.down==null && lane.destination==0) {
                model.deleted++;
                System.out.println("Vehicle deleted as lane "+lane.id+" is exceeded ("+model.deleted+"), dead end");
                delete();
            } else if (lane.down==null && lane.destination>0) {
                // vehicle has reached (a) destination
                if (model.settings.getBoolean("storeTrajectoryData")) {
                    model.saveTrajectoryData(trajectory);
                }
                delete();
            } else if (!route.canBeFollowedFrom(lane.down)) {
                model.deleted++;
                System.out.println("Vehicle deleted as lane "+lane.id+" is exceeded ("+model.deleted+"), route unreachable");
                delete();
            } else {
                // update route
                if (lane.destination>0) {
                    route = route.subRouteAfter(lane.destination);
                }
                // abort impossible lane change
                if (lcVehicle!=null) {
                    if ((lcDirection==jModel.latDirection.RIGHT && lane.down.right!=lcVehicle.lane.down) ||
                            (lcDirection==jModel.latDirection.LEFT && lane.down.left!=lcVehicle.lane.down)) {
                        abortLaneChange();
                    }
                }
                // check whether adjacent neighbours need to be reset
                // these will be found automatically by updateNeighbour() in
                // the main model loop
                if (lane.left!=null && lane.left.down!=lane.down.left) {
                    leftUp = null;
                    leftDown = null;
                }
                if (lane.right!=null && lane.right.down!=lane.down.right) {
                    rightUp = null;
                    rightDown = null;
                }
                // put on downstream lane
                x = x-lane.l;
                lane.vehicles.remove(this);
                lane.down.vehicles.add(this);
                lane = lane.down;
                // check whether RSU at start of lane is passed
                for (int i=0; i<lane.RSUcount(); i++) {
                    if (lane.getRSU(i).x<=x) {
                        lane.getRSU(i).pass(this);
                    }
                }
            }
        }
        // Move lane change vehicle
        if (lcVehicle != null) {
            double xNew = 0;
            double xAdj = 0;
            if (lcDirection==jModel.latDirection.LEFT) {
                xNew = getAdjacentX(jModel.latDirection.LEFT);
                xAdj = lcVehicle.lane.xAdj(lane.left);
            }
            else {
                xNew = getAdjacentX(jModel.latDirection.RIGHT);
                xAdj = lcVehicle.lane.xAdj(lane.right);
            }
            lcVehicle.translate(xNew+xAdj - lcVehicle.x);
            lcVehicle.a = a;
            lcVehicle.v = v;
            lcVehicle.setXY();
        }
    }

    /**
     * Starts a lane change by creating an <tt>lcVehicle</tt>.
     */
    public void startLaneChange() {
        lcVehicle = new jLcVehicle(this);//
        model.addVehicle(lcVehicle);//
        jLane atLane;
        if (lcDirection==jModel.latDirection.LEFT) {
            atLane = lane.left;
        } else {
            atLane = lane.right;
        }
        double atX = getAdjacentX(lcDirection);
        lcVehicle.paste(atLane, atX);
    }

    /**
     * Ends a lane change by deleting the <tt>lcVehicle</tt> and changing the lane.
     */
    public void endLaneChange() {
        // set vehicle at target lane and delete temporary vehicle
        lcVehicle.delete();
        jLane targetLane;
        double targetX = getAdjacentX(lcDirection);
        if (lcDirection==jModel.latDirection.LEFT) {
            targetLane = lane.left;
        } else {
            targetLane = lane.right;
        }
        cut();
        paste(targetLane, targetX);
        lcProgress = 0;
        dy = 0;
    }

    /**
     * Aborts a lane change by deleting the <tt>lcVehicle</tt>.
     */
    public void abortLaneChange() {
        // instantaneous abort of lane change
        lcVehicle.delete();
        lcProgress = 0;
        dy = 0;
    }

    /**
     * Initiates a lateral movement to the left.
     * @param dy Initial speed of the lateral movement in 'amount of lane per time step'.
     */
    public void changeLeft(double dy) {
        lcDirection = jModel.latDirection.LEFT;
        this.dy = dy;
    }

    /**
     * Initiates a lateral movement to the right.
     * @param dy Initial speed of the lateral movement in 'amount of lane per time step'.
     */
    public void changeRight(double dy) {
        lcDirection = jModel.latDirection.RIGHT;
        this.dy = dy;
    }

    /**
     * Sets global x and y coordinates. This may be in between two lanes in case
     * of a lane change.
     */
    public void setXY() {
        java.awt.geom.Point2D.Double coord = atLaneXY();
        if (lcVehicle!=null) {
            // interpolate between own and lcVehicle global X and Y
            globalX = coord.x*(1-lcProgress) + lcVehicle.globalX*lcProgress;
            globalY = coord.y*(1-lcProgress) + lcVehicle.globalY*lcProgress;
        }
        else {
            globalX = coord.x;
            globalY = coord.y;
        }
        heading = lane.heading(x);
    }

    /**
     * Returns the maximum vehicle speed in m/s.
     * @return Maximum vehicle speed [m/s].
     */
    public double getVMax() {
        return vMax/3.6;
    }

    /**
     * Returns the distance between a vehicle and an RSU.
     * @param rsu RSU.
     * @return Distance [m] between vehicle and RSU.
     */
    public double getDistanceToRSU(jRSU rsu) {
        return rsu.x + lane.xAdj(rsu.lane) - x;
    }

    /**
     * Correlates some parameters to other stochastic parameters. By default
     * this method is empty. Sub classes can define content for this method. The
     * method will be called after the stochastic parameters are set.
     */
    public void correlateParameters() {}

    /**
     * Returns whether the vehicle is equipped with an OBU.
     * @return Whether the car is equiped.
     */
    public boolean isEquipped() {
        return OBU!=null;
    }
    
    /**
     * Returns the driver of this vehicle.
     * @return Driver of this vehicle.
     */
    public jDriver getDriver() {
        return driver;
    }
}