package microModel;

/**
 * A single lane stretch of road. Different lanes are connected in the
 * longitudinal or lateral direction. The <tt>jLane</tt> object also provides a
 * few network utilities to find vehicles and to get the longitudinal distance
 * between lanes.
 */
public class jLane {

    /** Array of x-coordinates defining the lane curvature. */
    public double[] x;

    /** Array of y-coordinates defining the lane curvature. */
    public double[] y;

    /** Length of the lane [m]. */
    public double l;

    /** Main model. */
    public jModel model;

    /** ID of lane for user recognition. */
    protected int id;

    /** Downstream lane that is a taper (if any). */
    public jLane taper;

    /** Upstream lane (if any). */
    public jLane up;

    /** Downstream lane (if any). */
    public jLane down;

    /** Left lane (if any). */
    public jLane left;

    /** Right lane (if any). */
    public jLane right;

    /** Whether one can change to the left lane. */
    public boolean goLeft;

    /** Whether one can change to the right lane. */
    public boolean goRight;

    /** Set of RSUs, ordered by position. */
    protected java.util.ArrayList<jRSU> RSUs = new java.util.ArrayList<jRSU>();

    /** All movables on this lane, in no particular order. */
    public java.util.ArrayList<jMovable> vehicles = new java.util.ArrayList<jMovable>(0);

    /** Destination number, 0 if no destination. */
    public int destination;

    /** Legal speed limit. */
    public double vLim = 120;

    /**
     * Number of lane changes to be performed from this lane towards a certain
     * destination number. This is automatichally filled with the model
     * initialization.
     */
    public java.util.HashMap<Integer, Integer> lanechanges = new java.util.HashMap<Integer, Integer>();

    /**
     * Distance [m] in which lane changes have to be performed towards a certain
     * destination number. This is automatichally filled with the model
     * initialization.
     */
    public java.util.HashMap<Integer, Double> endpoints = new java.util.HashMap<Integer, Double>();

    /** Vehicle generator, if any. */
    public jGenerator generator;

    /**
     * Set of calculated x adjustments with longitudinally linked lanes. These
     * will be calculated and stored as needed.
     */
    protected java.util.HashMap<Integer, Double> xAdjust = new java.util.HashMap<Integer, Double>();

    /**
     * Constructor that will calculate the lane length from the x and y
     * coordinates.
     * @param x X coordinates of curvature.
     * @param y Y coordinates of curvature.
     * @param id User recognizable lane id.
     * @param model Main model.
     */
    @SuppressWarnings("OverridableMethodCallInConstructor")
    public jLane(jModel model, double[] x, double[] y, int id) {
        this.model = model;
        this.x = x;
        this.y = y;
        this.id = id;
        calculateLength();
    }
    
    /**
     * Sets the lane length based on the x and y coordinates. This method is 
     * called within the constructor and should only be used if coordinates are
     * changed afterwards (for instance to nicely connect lanes at the same 
     * point).
     */
    public void calculateLength() {
        // compute and set length
        double cumLength = 0;
        double dx;
        double dy;
        for (int i=1; i<=x.length-1; i++) {
            dx = this.x[i]-this.x[i-1];
            dy = this.y[i]-this.y[i-1];
            cumLength = cumLength + Math.sqrt(dx*dx + dy*dy);
        }
        l = cumLength;
    }

    /**
     * Initializes lane change info, taper presence, vehicle generation, RSUs.
     */
    public void init() {
        initLaneChangeInfo();
        if (taper==this) {
            jLane upLane = up;
            while (upLane!=null && upLane.left!=null) {
                upLane.taper = this;
                upLane = upLane.up;
            }
        }
        if (generator!=null) {
            generator.init();
        }
        for (int i=0; i<RSUs.size(); i++) {
            RSUs.get(i).init();
        }
    }
    
    /**
     * Initializes the lane change info throughout the network for a possible 
     * destination of this lane.
     */
    public void initLaneChangeInfo() {
        if (destination>0 && !leadsTo(destination)) {
            // find all lanes in cross section with same destination and set initial info
            java.util.ArrayList<jLane> curlanes = new java.util.ArrayList();
            curlanes.add(this);
            lanechanges.put(destination, 0);
            endpoints.put(destination, l);
            jLane lane = left;
            while (lane!=null && lane.destination==destination) {
                curlanes.add(lane);
                lane.lanechanges.put(destination, 0);
                lane.endpoints.put(destination, lane.l);
                lane = lane.left;
            }
            lane = right;
            while (lane!=null && lane.destination==destination) {
                curlanes.add(lane);
                lane.lanechanges.put(destination, 0);
                lane.endpoints.put(destination, lane.l);
                lane = lane.right;
            }
            // move through network and set lane change information
            while (!curlanes.isEmpty()) {
                // move left
                int n = curlanes.size();
                for (int i=0; i<n; i++) {
                    jLane curlane = curlanes.get(i);
                    int lcs = 0;
                    while (curlane.left!=null && curlane.left.goRight && 
                            !curlanes.contains(curlane.left) &&
                            !curlane.left.lanechanges.containsKey(destination)) {
                        // left lane is not in current set and has not been covered yet
                        lcs = lcs+1; // additional lane change required
                        curlanes.add(curlane.left); // add to current set
                        curlane.left.lanechanges.put(destination, lcs); // set # of lane changes
                        curlane.left.endpoints.put(destination, curlane.left.l);
                        curlane = curlane.left; // next left lane
                    }
                }
                // move right
                for (int i=0; i<n; i++) {
                    jLane curlane = curlanes.get(i);
                    int lcs = 0;
                    while (curlane.right!=null && curlane.right.goLeft && 
                            !curlanes.contains(curlane.right) &&
                            !curlane.right.lanechanges.containsKey(destination)) {
                        // right lane is not in current set and has not been covered yet
                        lcs = lcs+1; // additional lane change required
                        curlanes.add(curlane.right); // add to current set
                        curlane.right.lanechanges.put(destination, lcs); // set # of lane changes
                        curlane.right.endpoints.put(destination, curlane.right.l);
                        curlane = curlane.right; // next right lane
                    }
                }
                // move upstream
                java.util.ArrayList<jLane> uplanes = new java.util.ArrayList<jLane>();
                for (int i=0; i<curlanes.size(); i++) {
                    jLane curlane = curlanes.get(i);
                    if (curlane.up!=null && (!curlane.up.lanechanges.containsKey(destination) 
                            || curlane.up.lanechanges.get(destination)>curlane.lanechanges.get(destination)) ) {
                        // upstream lane is not covered yet or can be used with less lane changes
                        uplanes.add(curlane.up); // add to uplanes
                        // copy number of lane changes
                        curlane.up.lanechanges.put(destination, curlane.lanechanges.get(destination));
                        // increase with own length
                        curlane.up.endpoints.put(destination, curlane.endpoints.get(destination)+curlane.up.l);
                    }
                }
                // set curlanes for next loop
                curlanes = uplanes;
            }
        }
    }

    /**
     * Add RSU to lane. RSUs are ordered by position.
     * @param rsu
     */
    public void addRSU(jRSU rsu) {
        // order of RSUs is maintained
        int index = 0;
        if (!RSUs.isEmpty()) {
            if (rsu.x <= RSUs.get(0).x) {
                // RSU before first
                index = 0;
            } else if (RSUs.get(RSUs.size()-1).x <= rsu.x) {
                // RSU after last
                index = RSUs.size();
            } else {
                // RSU in between
                for (int i=0; i<RSUs.size()-1; i++) {
                    if (RSUs.get(i).x<= rsu.x && rsu.x <= RSUs.get(i+1).x) {
                        index = i+1;
                        i = RSUs.size(); // stop loop
                    }
                }
            }
        }
        RSUs.add(index, rsu);
    }

    /**
     * Removes RSU from this lane.
     * @param rsu RSU to remove.
     */
    public void removeRSU(jRSU rsu) {
        RSUs.remove(rsu);
    }

    /**
     * Returns the number of RSUs at this lane.
     * @return Number of RSUs.
     */
    public int RSUcount() {
        return RSUs.size();
    }

    /**
     * Returns the RSU at the given index.
     * @param index Index of requested RSU.
     * @return RSU at index.
     */
    public jRSU getRSU(int index) {
        return RSUs.get(index);
    }
    
    /**
     * Returns the ID of the lane.
     * @return ID of the lane.
     */
    public int id() {
        return id;
    }

    /**
     * Finds a movable beginning at some location and moving either up- or
     * downstream.
     * @param x Start location [m] for the search.
     * @param updown Whether to search up or downstream.
     * @return Found movable.
     */
    public jMovable findVehicle(double x, jModel.longDirection updown) {
        jMovable veh = null;
        if (updown==jModel.longDirection.UP) {
            // if there are vehicles on the lane, pick any vehicle
            if (!vehicles.isEmpty()) {
                veh = vehicles.get(0);
            }
            // search for upstream lane with vehicles
            else {
                jLane j = up;
                while (j!=null && j.vehicles.isEmpty()) {
                    j = j.up;
                }
                // pick any vehicle
                if (j!=null) {
                    veh = j.vehicles.get(0);
                }
            }
            // search up/downstream to match x
            if (veh != null) {
                while (veh.down != null && veh.down.x + xAdj(veh.down.lane) <= x) {
                    veh = veh.down;
                }
                while (veh != null && veh.x + xAdj(veh.lane) > x) {
                    veh = veh.up;
                }
            }
        } else if (updown==jModel.longDirection.DOWN) {
            // if there are vehicle on the lane, pick any vehicle
            if (!vehicles.isEmpty()) {
                veh = vehicles.get(0);
            }
            // search for downstream lane with vehicles
            else {
                jLane j = down;
                while (j!=null && j.vehicles.isEmpty()) {
                    j = j.down;
                }
                // pick any vehicle
                if (j!=null) {
                    veh = j.vehicles.get(0);
                }
            }
            // search up/downstream to match x
            if (veh != null) {
                while (veh.up != null && veh.up.x + xAdj(veh.up.lane) >= x) {
                    veh = veh.up;
                }
                while (veh != null && veh.x + xAdj(veh.lane) < x) {
                    veh = veh.down;
                }
            }
        }
        return veh;
    }

    /**
     * Finds the first noticeable RSU downstream of a location within a certain
     * range.
     * @param x Start location of search [m].
     * @param range Range of search [m].
     * @return Next noticeable RSU.
     */
    public jRSU findNoticeableRSU(double x, double range) {
        jLane atLane = this;
        double searchRange = 0;
        while (atLane!=null && searchRange<=range) {
            // Loop all RSUs on this lane
            for (int i=0; i<atLane.RSUcount(); i++) {
                if (atLane.getRSU(i).noticeable && xAdj(atLane)+atLane.getRSU(i).x>x 
                        && xAdj(atLane)+atLane.getRSU(i).x-x<=range) {
                    return atLane.getRSU(i);
                }
                // Update search range and quit if possible
                searchRange = xAdj(atLane)+atLane.getRSU(i).x-x;
                if (searchRange>range) {
                    return null;
                }
            }
            // If no noticable RSUs, move to next lane
            atLane = atLane.down;
            // Update searchrange at start of new lane
            searchRange = xAdj(atLane)-x;
        }
        return null;
    }

    /**
     * Finds the adjustment required to compare positions of two objects on
     * different but longitudinally connected lanes. A value is returned that 
     * can be added to the position of an object at <tt>otherLane</tt> to get
     * the appropiate position from the start of this lane. Note that the value
     * should always be added, no matter if <tt>otherLane</tt> is up- or 
     * downstream, as negaative adjustments may be returned. If the two lanes
     * are not up- or downstream from one another, 0 is returned.
     * @param otherLane Lane from which the adjustment is required.
     * @return Distance [m] to other lane.
     */
    public double xAdj(jLane otherLane) {
        double dx = 0;
        if (otherLane!=this && otherLane!=null) {
            if (xAdjust.containsKey(otherLane.id)) {
                // Get dx from xAdjust
                dx = xAdjust.get(otherLane.id);
            } else {
                // Calculate dx and store in xAdjust
                boolean found = false;
                // search downstream
                jLane j = this;
                while (j != null && !found) {
                    // increase downstream distance
                    dx = dx + j.l;
                    if (j.down == otherLane) {
                        // lane found
                        found = true;
                    }
                    j = j.down;
                }
                // not found, search upstream
                if (!found) {
                    dx = 0;
                    j = this;
                    while (j != null && !found) {
                        // reduce upstream distance
                        if (j.up != null) {
                            dx = dx - j.up.l;
                        }
                        if (j.up == otherLane) {
                            found = true;
                        }
                        j = j.up;
                    }
                }
                if (!found) {
                    dx = 0;
                }
                xAdjust.put(otherLane.id, dx);
            }
        }
        return dx;
    }
    
    /**
     * Checks whether two <tt>jLane</tt>s are in the same physical lane, e.g.
     * <tt>true</tt> if the two <tt>jLane</tt>s are downstream or upstream of 
     * one another.
     * @param otherLane The other <tt>jLane</tt>.
     * @return <tt>true</tt> of the lanes are in the same physical lane.
     */
    public boolean isSameLane(jLane otherLane) {
        if (otherLane==this) {
            return true;
        } else if (otherLane==null) {
            return false;
        } else {
            return xAdj(otherLane)!=0;
        }
    }

    /**
     * Returns the speed limit as m/s.
     * @return Speed limit [m/s]
     */
    public double getVLim() {
        return vLim/3.6;
    }

    /**
     * Returns the location of x on an adjacent lane keeping lane length 
     * difference and curvature in mind. If either lane change is possible the 
     * lanes are physically adjacent and it is assumed that curvature of both 
     * lanes is defined in adjacent straight sub-sections. If neither lane 
     * change is possible, the lanes may not be physically adjacent and only 
     * total length is considered.
     * @param x Location on this lane [m].
     * @param dir Left or right.
     * @return Adjacent location [m].
     */
    public double getAdjacentX(double x, jModel.latDirection dir) {
        if (dir==jModel.latDirection.LEFT && !goLeft && !left.goRight) {
            // maybe not physically adjacent, use total length only
            return x * left.l/l;
        } else if (dir==jModel.latDirection.RIGHT && !goRight && !right.goLeft) {
            // maybe not physically adjacent, use total length only
            return x * right.l/l;
        } else {
            // get appropiate section, and fraction within section
            double xCumul = 0; // length at end of appropiate section
            int section = 0;
            double dx = 0;
            double dy = 0;
            if (x>l) {
                // last section
                section = this.x.length-2;
                dx = this.x[section+1]-this.x[section];
                dy = this.y[section+1]-this.y[section];
                xCumul = l;
            } else if (x<=0) {
                // first section
                dx = this.x[section+1]-this.x[section];
                dy = this.y[section+1]-this.y[section];
                xCumul = Math.sqrt(dx*dx + dy*dy);
            } else {
                // find section by looping
                while (xCumul<x) {
                    dx = this.x[section+1]-this.x[section];
                    dy = this.y[section+1]-this.y[section];
                    xCumul = xCumul + Math.sqrt(dx*dx + dy*dy);
                    section++;
                }
                section--;
            }
            double lSection = Math.sqrt(dx*dx + dy*dy); // length of appropiate section
            double fSection = 1-(xCumul-x)/lSection; // fraction within appropiate section
            // loop appropiate adjacent lane
            jLane lane = null;
            if (dir==jModel.latDirection.LEFT) {
                lane = left;
            } else if (dir==jModel.latDirection.RIGHT) {
                lane = right;
            }
            // loop preceding sections
            double xStart = 0;
            for (int i=0; i<section; i++) {
                dx = lane.x[i+1]-lane.x[i];
                dy = lane.y[i+1]-lane.y[i];
                xStart = xStart + Math.sqrt(dx*dx + dy*dy);
            }
            // add part of appropiate section
            dx = lane.x[section+1]-lane.x[section];
            dy = lane.y[section+1]-lane.y[section];
            return xStart + fSection*Math.sqrt(dx*dx + dy*dy);
        }
    }

    /**
     * Utility to connect this lane with right lane.
     * @param goRight Whether change from this lane to right is possible.
     * @param right The right lane.
     * @param goLeft Whether change from right to this lane is possible.
     */
    public void connectLat(boolean goRight, jLane right, boolean goLeft) {
        this.right = right;
        this.goRight = goRight;
        right.left = this;
        right.goLeft = goLeft;
    }

    /**
     * Utility to connect this lane with upstream lane.
     * @param up The upstream lane.
     */
    public void connectLong(jLane up) {
        up.down = this;
        this.up = up;
    }

    /**
     * Returns the global x and y at the lane centre.
     * @param pos Position [m] on the lane.
     * @return Point with x and y coordinate.
     */
    public java.awt.geom.Point2D.Double XY(double pos) {
        double cumlength[] = new double[x.length];
        cumlength[0] = 0;
        double dx; // section distance in x
        double dy; // section distance in y
        int section = -1; // current section of vehicle
        // calculate cumulative lengths untill x of vehicle is passed
        for (int i=1; i<x.length; i++) {
            dx = x[i] - x[i-1];
            dy = y[i] - y[i-1];
            cumlength[i] = cumlength[i-1] + java.lang.Math.sqrt(dx*dx + dy*dy);
            if (section==-1 && cumlength[i]>pos) {
                section = i;
                i = x.length; // stop loop
            }
        }
        if (section==-1) {
            // the vehicle is probably beyond the lane, extrapolate from last section
            section = x.length-1;
        }
        double x0 = x[section-1]; // start of current section
        double y0 = y[section-1];
        double x1 = x[section]; // end of current section
        double y1 = y[section];
        double res = pos-cumlength[section-1]; // distance within section
        double sec = cumlength[section] - cumlength[section-1]; // section length
        return new java.awt.geom.Point2D.Double(x0 + (x1-x0)*(res/sec), y0 + (y1-y0)*(res/sec));
    }
    
    /**
     * Returns the heading on the lane at the given position. The returned
     * <tt>Point2D.Double</tt> object is not actually a point. Instead, the x
     * and y values are the x and y headings.<br>
     * <pre><tt>
     *            x
     *       ----------
     *       |'-.
     *     y |   '-. 
     *       |      '-. heading, length = sqrt(x^2 + y^2) = 1</tt></pre> 
     * @param pos Position [m] on the lane.
     * @return Point where x and y are the x and y headings.
     */
    public java.awt.geom.Point2D.Double heading(double pos) {
        double cumlength[] = new double[x.length];
        cumlength[0] = 0;
        double dx; // section distance in x
        double dy; // section distance in y
        int section = -1; // current section of vehicle
        // calculate cumulative lengths untill x of vehicle is passed
        for (int i=1; i<x.length; i++) {
            dx = x[i] - x[i-1];
            dy = y[i] - y[i-1];
            cumlength[i] = cumlength[i-1] + java.lang.Math.sqrt(dx*dx + dy*dy);
            if (section==-1 && cumlength[i]>pos) {
                section = i;
                i = x.length; // stop loop
            }
        }
        if (section==-1) {
            // the vehicle is probably beyond the lane, extrapolate from last section
            section = x.length-1;
        }
        dx = x[section] - x[section-1];
        dy = y[section] - y[section-1];
        double f = 1/Math.sqrt(dx*dx + dy*dy);
        return new java.awt.geom.Point2D.Double(dx*f, dy*f);
    }
    
    /**
     * Returns whether the destination can be reached from this lane.
     * @param destination Destination of interest.
     * @return Whether this lane leads to the given destination.
     */
    public boolean leadsTo(int destination) {
        return lanechanges.containsKey(destination);
    }
    
    /**
     * Returns the number of lane changes required to go to the given destination.
     * @param destination Destination of interest.
     * @return The number of lane changes for the destination.
     */
    public int nLaneChanges(int destination) {
        return lanechanges.get(destination);
    }
    
    /**
     * Returns the number of lane changes that need to be performed to go to
     * the destination from this lane.
     * @param destination Destination of interest.
     * @return Number of lane changes that needs to be performed for this destination.
     */
    public double xLaneChanges(int destination) {
        return endpoints.get(destination);
    }
}