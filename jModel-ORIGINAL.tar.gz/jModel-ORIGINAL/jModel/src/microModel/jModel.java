package microModel;

/**
 * Main model object. This functions as the main interface with the model. It
 * contains general settings, the network, all vehicles etc. Furthermore, it
 * represents the world.
 */
public class jModel  {

    /** Time step number. Always starts as 0. */
    protected int k;
    
    /** Current time of the model [s]. Always starts at 0. */
    protected double t;
    
    /** Time step size of the model [s]. */
    public double dt;
    
    /** Maximum simulation period [s]. */
    public double period;
    
    /** Absolute start time of simulation. */
    public java.util.Date startTime;
    
    /** 
     * Generator for random numbers. This generator is connected to the seed and
     * should be used for all operations that are random and should be 
     * repeatable. Before the generator can be used, the seed needs to be set
     * using <tt>setSeed</tt>.
     */
    protected java.util.Random rand;
    
    /** Set of all vehicles in simulation. */
    protected java.util.ArrayList<jVehicle> vehicles = new java.util.ArrayList<jVehicle>();
    
    /** Set of all temporary lane change vehicles in simulation. */
    protected java.util.ArrayList<jLcVehicle> lcVehicles = new java.util.ArrayList<jLcVehicle>();
    
    /** Set of lanes that make up the network. */
    public jLane[] network = new jLane[0];
    
    /** Set of all vehicle-driver classes. */
    protected java.util.ArrayList<jClass> classes = new java.util.ArrayList<jClass>();
    
    /** Set of controllers, both local and regional. */
    protected java.util.ArrayList<jController> controllers = new java.util.ArrayList<jController>();
    
    /** Total number of deleted vehicles. */
    protected int deleted = 0;
    
    /** 
     * Enables debugging mode. User-defined classes can use this to feedback 
     * information. 
     */
    public boolean debug = false;
    
    /** 
     * Enabled during vehicle generation. This is used to disable acceleration 
     * bookkeeping during generation attempts. 
     */
    protected boolean generating = false;
    
    /** Expandable set of general modelling settings. */
    public jSettings settings = new jSettings();
    
    /** Temporary trajectory storage before a set is saved to disk. */
    protected java.util.ArrayList<jTrajectoryData> trajectories = 
            new java.util.ArrayList<jTrajectoryData>();
    
    /** Counter of all saved trajectories. This is part of the filename. */
    protected int trajectoriesSaved = 0;
    
    /**
     * Constructor that sets some default settings.<br>
     * <br><pre>
     * boolean "storeTrajectoryData" = false
     * double  "trajectoryPeriod"    = 1
     * int     "trajectoryBuffer"    = 50
     * boolean "storeDetectorData"   = false
     * double  "detectorDelay"       = 120
     * double  "detectorPeriod"      = 60
     * String  "outputDir"           = "output"</pre>
     */
    public jModel() {
        // trajectory data for analysis
        settings.putBoolean("storeTrajectoryData", false);
        settings.putDouble("trajectoryPeriod", 1); // sampling period
        settings.putInteger("trajectoryBuffer", 50); // trajectories saved on disc
        // detector data for analysis
        settings.putBoolean("storeDetectorData", false);
        settings.putDouble("detectorDelay", 120); // send delay
        settings.putDouble("detectorPeriod", 60); // aggregation period
        // directory
        settings.putString("outputDir", "output");
    }
    
    /**
     * Sets the seed and initializes the random generator.
     * @param s Random seed.
     */
    public void setSeed(long s) {
        rand = new java.util.Random();
        rand.setSeed(s);
    }
    
    /**
     * Initializes the model. This includes setting the lane change info per
     * lane and destination, initializing the vehicle generation and RSUs of the
     * lanes and initializing controllers. This method needs to be called before
     * running the model.
     */
    public void init() {

        // Set attributes
        k = 0;
        t = 0;
        vehicles = new java.util.ArrayList<jVehicle>();
        lcVehicles = new java.util.ArrayList<jLcVehicle>();

        // Initialize lanes
        for (int i=0; i<network.length; i++) {
            network[i].init();
        }
        
        // Initialize controllers
        for (int i=0; i<controllers.size(); i++) {
            controllers.get(i).init();
        }
    }

    /**
     * Performs the main model loop. This entails the RSUs, OBUs, controllers, 
     * vehicle generators and drivers (in this order).
     * @param n Number of loops to be run before returning.
     */
    public void run(int n) {

        // loop n times
        int nn = 0;
        while (nn<n && t<period) {

            // Run road-side units
            for (int i=0; i<network.length; i++) {
                for (int j=0; j<network[i].RSUcount(); j++) {
                    network[i].getRSU(j).run();
                }
            }
            // Run on-board units
            for (int i=0; i<vehicles.size(); i++) {
                if (vehicles.get(i).isEquipped()) {
                    vehicles.get(i).OBU.run();
                }
            }
            // Run controllers
            for (int i=0; i<controllers.size(); i++) {
                controllers.get(i).run();
            }

            // Vehicle generation
            generating = true;
            for (int i=0; i<network.length; i++) {
                if (network[i].generator!=null) {
                    network[i].generator.run();
                }
            }
            generating = false;

            // Drive
            // copy pointer array as vehicles may be deleted
            java.util.ArrayList<jVehicle> tmp = new java.util.ArrayList<jVehicle>(vehicles.size());
            for (int i=0; i<vehicles.size(); i++) {
                tmp.add(i, vehicles.get(i));
            }
            for (int i=0; i<tmp.size(); i++) {
                tmp.get(i).driver.drive(); // sets a and dy
                if (tmp.get(i).dy!=0 && tmp.get(i).lcProgress==0) {
                    tmp.get(i).startLaneChange();
                }
            }

            // Move
            // copy pointer array as vehicles may be deleted
            tmp.clear();
            for (int i=0; i<vehicles.size(); i++) {
                tmp.add(i, vehicles.get(i));
            }
            for (int i=0; i<tmp.size(); i++) {
                tmp.get(i).move(); // performs a and dy
            }

            // Update all neighbour references (overtaking)
            for (int i=0; i<vehicles.size(); i++) {
                vehicles.get(i).updateNeighbours();
            }
            for (int i=0; i<lcVehicles.size(); i++) {
                lcVehicles.get(i).updateNeighbours();
            }

            // End lane changes
            for (int i=0; i<vehicles.size(); i++) {
                if (vehicles.get(i).lcProgress>=1) {
                    vehicles.get(i).endLaneChange();
                }
            }
            
            // Check for collisions
            if (debug) {
                for (int i=0; i<vehicles.size(); i++) {
                    if (vehicles.get(i).down!=null && vehicles.get(i).getHeadway(vehicles.get(i).down)<0) {
                        System.err.println("Collision: "+vehicles.get(i).x+"@"+vehicles.get(i).lane.id);
                    }
                }
            }

            // Update time
            k = k+1; // time step number
            t = k*dt; // time [s]

            nn++;
        }
    }

    /** 
     * Adds a class to the model.
     * @param cls Class to add.
     */
    protected void addClass(jClass cls) {
        classes.add(cls);
    }
    
    /**
     * Returns the class with given id.
     * @param id Id of requested class.
     * @return Class with given id.
     */
    public jClass getClass(int id) {
        for (int i=0; i<classes.size(); i++) {
            if (classes.get(i).id() == id) {
                return classes.get(i);
            }
        }
        return null;
    }
    
    /**
     * Adds a vehicle in the simulation.
     * @param vehicle Vehicle to add.
     */
    public void addVehicle(jMovable vehicle) {
        if (vehicle instanceof jVehicle) {
            vehicles.add((jVehicle) vehicle);
        } else if (vehicle instanceof jLcVehicle) {
            lcVehicles.add((jLcVehicle) vehicle);
        }
    }
    
    /**
     * Removes a vehicle from the simulation.
     * @param vehicle Vehicle to remove.
     */
    public void removeVehicle(jMovable vehicle) {
        if (vehicle instanceof jVehicle) {
            vehicles.remove((jVehicle) vehicle);
        } else if (vehicle instanceof jLcVehicle) {
            lcVehicles.remove((jLcVehicle) vehicle);
        }
    }
    
    /**
     * Returns the current array of vehicles in simulation.
     * @return Array of vehicles in simulation.
     */
    public java.util.ArrayList<jVehicle> getVehicles() {
        return vehicles;
    }
    
    /**
     * Returns the current array of lcVehicles in simulation.
     * @return Array of lcVehicles in simulation.
     */
    public java.util.ArrayList<jLcVehicle> getLcVehicles() {
        return lcVehicles;
    }
    
    /**
     * Displays messages whenever any movable in simulation has a pointer to the
     * given movable. This can be used to check whether the given movable was 
     * correctly cut from simulation after the <tt>jMovable.cut()</tt> method.
     * @param movable Cut movable.
     */
    public void checkForRemainingPointers(jMovable movable) {
        jLane lane = movable.lane;
        double x = movable.x;
        java.util.Iterator<jVehicle> iter = vehicles.iterator();
        while (iter.hasNext()) {
            jVehicle veh = iter.next();
            if (veh.up==movable || veh.down==movable || veh.leftUp==movable ||
                    veh.leftDown==movable || veh.rightUp==movable || veh.rightDown==movable) {
                System.err.println("Cut vehicle: "+x+"@"+lane.id+
                        ", still connected: "+veh.x+"@"+veh.lane.id);
            }
        }
        java.util.Iterator<jLcVehicle> iterLc = lcVehicles.iterator();
        while (iterLc.hasNext()) {
            jLcVehicle veh = iterLc.next();
            if (veh.up==movable || veh.down==movable || veh.leftUp==movable ||
                    veh.leftDown==movable || veh.rightUp==movable || veh.rightDown==movable) {
                System.err.println("Cut vehicle: "+x+"@"+lane.id+
                        ", still connected: "+veh.x+"@"+veh.lane.id);
            }
        }
    }
    
    /**
     * Adds a controller to the model.
     * @param controller Controller to add.
     */
    public void addController(jController controller) {
        controllers.add(controller);
    }
    
    /**
     * Derives the current absolute time of the simulation as being <tt>t</tt>
     * seconds after the given <tt>startTime</tt>. If no <tt>startTime</tt> is
     * given, <tt>null</tt> is returned.
     * @return Absolute current time.
     */
    public java.util.Date currentTime() {
        if (startTime==null) {
            return null;    
        } else {
            return new java.util.Date(startTime.getTime() + (long) (t*1000));
        }
    }
    
    /**
     * Returns the current time in simulation.
     * @return Current time [s].
     */
    public double t() {
        return t;
    }
    
    /**
     * Returns the random generator.
     * @return Random generator.
     */
    public java.util.Random random() {
        return rand;
    }
    
    /**
     * Returns the number of deleted vehicles.
     * @return Number of deleted vehicles.
     */
    public int deletedVehicles() {
        return deleted;
    }
    
    /**
     * Returns whether the model is in the vehicle generation phase.
     * @return Whether the model is in the vehicle generation phase.
     */
    public boolean isGenerating() {
        return generating;
    }

    /**
     * Returns a lognormally distributed random number where the lognormal
     * distribution has mean <tt>m</tt> and standard deviation <tt>s</tt>. Note 
     * that these are not the same as the mu and sigma of the variable's natural 
     * logarithm.
     * @param m Mean of the lognormal distribution.
     * @param s Standard deviation of the lognormal distribution.
     * @return Random lognormally distributed number.
     */
    public double lognormal(double m, double s) {
        double mu = Math.log(m*m / Math.sqrt(s*s+m*m));
        double sigma = Math.sqrt(Math.log((s*s/(m*m)) + 1));
        double r = Math.exp(mu + rand.nextDouble()*sigma);
        return r;
    }

    /**
     * Stores all requested data. This may include all trajectories of vehicles 
     * still in simulation and in the buffer and all detectors. Typically, this
     * method is called after the simulation has finished.
     */
    public void storeData() {
        // Store remaining vehicles
        if (settings.getBoolean("storeTrajectoryData")) {
            for (int i=0; i<vehicles.size(); i++) {
                saveTrajectoryData(vehicles.get(i).trajectory);
            }
            saveTrajectoryBufferToDisk();
        }
        if (settings.getBoolean("storeDetectorData")) {
            // Store detector data
            for (int i=0; i<network.length; i++) {
                for (int j=0; j<network[i].RSUcount(); j++) {
                    if (network[i].getRSU(j) instanceof jDetector) {
                        saveDetectorData((jDetector) network[i].getRSU(j));
                    }
                }
            }
        }
    }

    /**
     * Saves trajectory in memory and saves buffer to disk if it is full.
     * @param trajectory
     */
    public synchronized void saveTrajectoryData(jTrajectory trajectory) {
        trajectories.add(new jTrajectoryData(trajectory));
        if (trajectories.size() >= settings.getInteger("trajectoryBuffer")) {
            saveTrajectoryBufferToDisk();
        }
    }
    
    /**
     * Saves the trajectory buffer, no matter what size, to disk. The buffer
     * will be empty afterwards.
     */
    protected synchronized void saveTrajectoryBufferToDisk() {
        // Save trajectories on drive
        try {
            java.io.File f = new java.io.File(settings.getString("outputDir"), "trajectories");
            f.mkdir();
            java.text.DecimalFormat df = new java.text.DecimalFormat("000000");
            for (int i=0; i<trajectories.size(); i++) {
                trajectoriesSaved++;
                java.io.FileOutputStream fos = new java.io.FileOutputStream(
                        settings.getString("outputDir")+"/trajectories/trajectory"+
                        df.format(trajectoriesSaved)+".dat");
                java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(fos);
                java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(bos);
                oos.writeObject(trajectories.get(i));
                oos.close();
            }
        } catch (Exception e) {
            System.err.println("Unable to write to file: "+e.getMessage());
        }
        trajectories.clear();
    }

    /**
     * Utility to load trajectory data from file.
     * @param file .dat file of object.
     * @return Trajectory data.
     */
    public static jTrajectoryData loadTrajectoryData(java.lang.String file) {
        jTrajectoryData out = null;
        try {
            java.io.FileInputStream fis = new java.io.FileInputStream(file);
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            out = (jTrajectoryData) ois.readObject();
            fis.close();
        } catch (Exception e) {
            System.err.println("Unable to read from file: "+e.getMessage());
        }
        return out;
    }

    /**
     * Saves detector data to disk in a file with the detector id in the name.
     * @param detector Detector.
     */
    public void saveDetectorData(jDetector detector) {
        jDetectorData dd = new jDetectorData(detector);
        // Save detector to disk.
        try {
            java.io.File f = new java.io.File(settings.getString("outputDir"), "detectors");
            f.mkdir();
            java.io.FileOutputStream fos = new java.io.FileOutputStream(
                    settings.getString("outputDir")+"/detectors/detector"+detector.id()+".dat");
            java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(fos);
            java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(bos);
            oos.writeObject(dd);
            oos.close();
        } catch (Exception e) {
            System.err.println("Unable to write to file: "+e.getMessage());
        }
    }

    /**
     * Utility to load detector data from file.
     * @param file .dat file of object.
     * @return Detector data.
     */
    public static jDetectorData loadDetectorData(java.lang.String file) {
        jDetectorData out = null;
        try {
            java.io.FileInputStream fis = new java.io.FileInputStream(file);
            java.io.ObjectInputStream ois = new java.io.ObjectInputStream(fis);
            out = (jDetectorData) ois.readObject();
            fis.close();
        } catch (Exception e) {
            System.err.println("Unable to read from file: "+e.getMessage());
        }
        return out;
    }

    /** Enumeration of longitudinal directions. */
    public enum longDirection {
        /** Upstream direction. */
        UP, 
        /** Downstream direction. */
        DOWN
    }
    
    /** Enumeration of lateral directions. */
    public enum latDirection {
        /** Left direction. */
        LEFT, 
        /** Right direction. */
        RIGHT
    }
}