package microModel;

/**
 * Default wrapper for a driver. The drive method is the main method and should
 * set <tt>a</tt> and <tt>dy</tt> of the vehicle. The longitudinal model is 
 * situated in the calculateAcceleration method. For efficiency accelerations 
 * may be stored between any two vehicles. These can be used multiple times 
 * using the getAcceleration method.
 */
public class jDriver {

    /** Acceleration storage for use with the <tt>getAcceleration</tt> methods. */
    protected java.util.HashMap<jMovable, java.util.HashMap<java.lang.String, Double>> accelerations =
            new java.util.HashMap<jMovable, java.util.HashMap<java.lang.String, Double>>();
    
    /** Time of stored accelerations (for <tt>getAcceleration</tt>). */
    protected double tAcc;

    /** IDM stopping distance [m]. */
    public double s0 = 3;
    
    /** IDM acceleration [m/s^2]. */
    public double a = 1.25;
    
    /** IDM deceleration [m/s^2]. */
    public double b = 2.09;
    
    /** IDM regular following headway [s]. */
    public double Tmax = 1.2;

    /** LMRS lane change desire to the left. */ 
    public double dLeft = 0;
    
    /** LMRS lane change desire to the right. */
    public double dRight = 0;
    
    /** Whether driver is synchronizing with the left lane. */
    public boolean leftSync = false;
    
    /** Whether driver is synchronizing with the right lane. */
    public boolean rightSync = false;
    
    /** Whether driver is yielding for a vehicle in the right lane (for a left lane change). */
    public boolean leftYield = false;
    
    /** Whether driver is yielding for a vehicle in the left lane (for a right lane change). */
    public boolean rightYield = false;

    /** LMRS free lane change threshold. */
    public double dFree = .365;
    
    /** LMRS synchronized lane change threshold. */
    public double dSync = .577;
    
    /** LMRS cooperative lane change threshold. */
    public double dCoop = .788;
    
    /** LMRS mandatory lane change time [s]. */
    public double t0 = 43;
    
    /** LMRS mandatory lane change distance [m]. */
    public double x0 = 295;
    
    /** LMRS speed gain [m/s] for full desire. */
    public double vGain = 69.6/3.6;
    
    /** LMRS critical speed [m/s] for a speed gain in the right lane. */
    public double vCong = 60/3.6;
    
    /** LMRS deceleration for lane changes (default: equal to <tt>b</tt>). */
    public double bSafe = 2.09;
    
    /** LMRS minimum time headway [s] for very desired lane change. */
    public double Tmin = .56;
    
    /** LMRS relaxation time [s] for headway relaxation after lane change. */
    public double tau = 25;
    
    /** Temporary T value between <tt>setT</tt> and <tt>resetT</tt> invocations. */
    protected double Ttmp = Tmax;

    /** Maximum deceleration [m/s^2] for a red light (otherwise jumped). */
    public double bRed = 5;
    
    /** (Maximum) distance [m] at which RSUs may be noticed. */
    public double noticeableRange = 300;
    
    /** Last time when acceleration was lowered using <tt>lowerAcceleration</tt>. */
    protected double tAccLower = -1;

    /** Bookkeeping of influence on anticipated speed from a left lane. */
    protected java.util.HashMap<jLane, Double> antFromLeft = new java.util.HashMap<jLane, Double>();
    
    /** Bookkeeping of influence on anticipated speed from given lane. */
    protected java.util.HashMap<jLane, Double> antInLane = new java.util.HashMap<jLane, Double>();
    
    /** Bookkeeping of influence on anticipated speed from a right lane. */
    protected java.util.HashMap<jLane, Double> antFromRight = new java.util.HashMap<jLane, Double>();
    
    /** Current time of anticipated speed bookkeeping (for <tt>anticipatedSpeed</tt>). */
    protected double tAnt;

    /** Current value for the headway [s], initiated at <tt>Tmax</tt>. */
    protected double T = Tmax;
    
    /** Speed limit adherence factor. */
    public double fSpeed = 1;
    
    /** Duration [s] of a lane change. */
    public double duration = 3;
    
    /** Vehicle of the driver. */
    public jVehicle vehicle;
    
    /** Current desired velocity. Use <tt>desiredVelocity()</tt> to get it. */
    protected double vDes;
    
    /** Time of calculated desired velocity (for <tt>desiredVelocity()</tt>). */
    protected double vDesT = -1;
    
    /** Whether the notice(jRSU) method is in the stack trace. */
    private boolean inGeneralNotice = false;

    /**
     * Constructor which links the driver with a vehicle and vice versa.
     * @param vehicle Vehicle of the driver.
     */
    // using this at the end is ok, driver is fully initialized
    @SuppressWarnings("LeakingThisInConstructor") 
    public jDriver(jVehicle vehicle) {
        this.vehicle = vehicle;
        vehicle.driver = this;
    }

    /**
     * Driver behavior for acceleration and lane changes. This is the main
     * function that sets <code>a</code> (acceleration) and <code>dy</code>
     * (lateral change) of the vehicle. The latter is either set using 
     * <tt>vehicle.changeLeft(dy)</tt> or <tt>vehicle.changeRight(dy)</tt>. It 
     * combines the Intelligent Driver Model+ (IDM+) and the Lane-change Model 
     * with Relaxation and Synchronisation (LMRS).<br>
     * <br>
     * IDM+<br>
     * This is the longitudinal car-following model that determines acceleration
     * based on the gap, velocity and relative velocity.<br>
     * <br>
     * LMRS<br>
     * This is the lateral lane change model that is based on lane change desire
     * based on incentives of: following a route, gaining speed, and following
     * traffic rules. Depending on the level of desire a vehicle may start to
     * synchronize with the target lane, or a gap may even be created.
     */
    public void drive() {

        // Notice RSU's
        noticeRSUs();
        
        // Set interaction booleans as false by default
        leftSync = false; // for visualisation only
        rightSync = false;
        leftYield = false;
        rightYield = false;
        vehicle.leftIndicator = false; // for vehicle interaction
        vehicle.rightIndicator = false;
        
        // Perform the lane change model only when not changing lane
        if (vehicle.lcProgress == 0) {

            /* The headway is exponentially relaxed towards the normal value of
             * Tmax. The relaxation time is tau, which can never be smaller than
             * the time step. Smaller values of T can be set within the model.
             */
            T = T + (Tmax-T)*vehicle.model.dt/(tau>=vehicle.model.dt?tau:vehicle.model.dt);

            /* A lane change is not considered over the first 100m of lanes with
             * generators. Vehicles that are (virtually) upstream of the network
             * would influence this decision so the model is not valid here.
             */
            if (vehicle.x>100 || vehicle.lane.generator==null) {
                
                /* === ROUTE ===
                 * First, the lane change desire to leave a lane for the route
                 * on the left, current and right lane is determined based on
                 * remaining distance and remaining time.
                 */
                // Get remaining distance and number of lane changes from lane
                double xCur = vehicle.route.xLaneChanges(vehicle.lane) - vehicle.x;
                int nCur = vehicle.route.nLaneChanges(vehicle.lane);
                /* Desire to leave the current lane is eiter based on remaining
                 * distance or time. For every lane change required, a certain
                 * distance or time is desired.
                 */
                // Towards the left, always ignore taper on current lane
                double dCurRouteFL = Math.max(Math.max(1-(xCur/(nCur*x0)),
                        1-((xCur/vehicle.v)/(nCur*t0))), 0);
                // Towards the right, no desire if on taper
                double dCurRouteFR = 0;
                if (!isOnTaper()) {
                    dCurRouteFR = dCurRouteFL;
                }
                /* Determine desire to leave the left lane if it exists and
                 * allows to follow the route.
                 */
                double dLeftRoute = 0;
                if (vehicle.lane.left!=null && vehicle.route.canBeFollowedFrom(vehicle.lane)) {
                    // The first steps are similar as in the current lane
                    int nLeft = vehicle.route.nLaneChanges(vehicle.lane.left);
                    double xLeft = vehicle.route.xLaneChanges(vehicle.lane.left)
                            - vehicle.getAdjacentX(jModel.latDirection.LEFT);
                    // We can always include a taper on the left lane if it's there
                    if (!isTaper(vehicle.lane.left)) {
                        dLeftRoute = Math.max(Math.max(1-(xLeft/(nLeft*x0)),
                                1-((xLeft/vehicle.v)/(nLeft*t0))), 0);
                    }
                    
                    /* We now have the desire to leave the current, and to leave
                     * the left lane. 'dLeftRoute' will now become the actual
                     * desire to change to the left lane by comparing the two.
                     * If desire to leave the left lane is lower, the desire to
                     * leave the current lane is used. If they are equal, the
                     * desire is zero. If the left lane is worse, the desire to
                     * go left is negative and equal to the desire to leave the
                     * left lane. In this way we have symmetry which prevents
                     * lane hopping.
                     */
                    if (dLeftRoute<dCurRouteFL) {
                        dLeftRoute = dCurRouteFL;
                    } else if (dLeftRoute>dCurRouteFL) {
                        dLeftRoute = -dLeftRoute;
                    } else {
                        dLeftRoute = 0;
                    }
                } else {
                    // Destination becomes unreachable after lane change
                    dLeftRoute = Double.NEGATIVE_INFINITY;
                }
                // Idem. for right lane
                double dRightRoute = 0;
                if (vehicle.lane.right!=null && vehicle.route.canBeFollowedFrom(vehicle.lane)) {
                    int nRight = vehicle.route.nLaneChanges(vehicle.lane.right);
                    double xRight = vehicle.route.xLaneChanges(vehicle.lane.right)
                            - vehicle.getAdjacentX(jModel.latDirection.RIGHT);
                    // A taper on the right lane is never applicable
                    dRightRoute = Math.max(Math.max(1-(xRight/(nRight*x0)),
                            1-((xRight/vehicle.v)/(nRight*t0))), 0);
                    
                    if (dRightRoute<dCurRouteFR) {
                        dRightRoute = dCurRouteFR;
                    } else if (dRightRoute>dCurRouteFR) {
                        dRightRoute = -dRightRoute;
                    } else {
                        dRightRoute = 0;
                    }
                } else {
                    dRightRoute = Double.NEGATIVE_INFINITY;
                }

                /* === SPEED GAIN ===
                 * Drivers may change lane to gain speed. They assess an
                 * anticipated speed.
                 */
                // Get anticipated speeds in current and adjacent lanes
                double vAntLeft = anticipatedSpeed(vehicle.lane.left);
                double vAntCur = anticipatedSpeed(vehicle.lane);
                double vAntRight = anticipatedSpeed(vehicle.lane.right);
                /* An acceleration factor is determined. As drivers accelerate
                 * more, their lane change desire for speed reduces. This
                 * prevents slow accelerating vehicles from changing lane when
                 * being overtaken by fast accelerating vehicles. This would
                 * otherwise cause unreasonable lane changes.
                 */
                double aGain = (a-Math.max(calculateAcceleration(vehicle, vehicle.down),0))/a;
                /* Desire to the left is related to a possible speed gain/loss.
                 * The parameter vGain determines for which speed gain the
                 * desire would be 1. Desire is 0 if there is no left lane or if
                 * it is prohibited or impossible to go there.
                 */
                double dLeftSpeed = 0;
                if (vehicle.lane.goLeft) {
                    dLeftSpeed = aGain*(vAntLeft-vAntCur)/vGain;
                }
                /* For the right lane, desire due to a speed gain is slightly
                 * different. As one is not allowed to overtake on the right, a
                 * speed gain is reduced to 0. A speed loss is still considered.
                 * For this, traffic should be free flow as one may overtake on
                 * the right in congestion.
                 */
                double dRightSpeed = 0;
                if (vehicle.lane.goRight) {
                    if (vAntCur>=vCong) {
                        dRightSpeed = aGain*Math.min(vAntRight-vAntCur, 0)/vGain;
                    } else {
                        dRightSpeed = aGain*(vAntRight-vAntCur)/vGain;
                    }
                }
     
                /* === LANE CHANGE BIAS ===
                 * Drivers have to keep right. It is assumed that this is only
                 * obeyed in free flow and when the anticipated speed on the
                 * right lane is equal to the desired speed. Or in other words,
                 * when there is no slower vehicle nearby in the right lane.
                 * The bias is equal to the free threshold, just triggering
                 * drivers to change in free conditions. Another condition is
                 * that there should be no route undesire towards the right
                 * whatsoever.
                 */
                double dLeftBias = 0;
                double dRightBias = 0;
                if (vAntRight==desiredVelocity() && dRightRoute>=0) {
                    dRightBias = dFree;
                }
                
                /* === TOTAL DESIRE ===
                 * Depending on the level of desire from the route (mandatory),
                 * the speed and keep right (voluntary) incentives may be
                 * included partially or not at all. If the incentives are in
                 * the same direction, voluntary incentives are fully included.
                 * Otherwise, the voluntary incentives are less and less
                 * considered within the range dSync < |dRoute| < dCoop. The
                 * absolute value of dRouite is used as negative values may also
                 * dominate voluntary incentives.
                 */
                double thetaLeft = 0; // Assume not included
                if (dLeftRoute*(dLeftSpeed+dLeftBias)>=0 || Math.abs(dLeftRoute)<=dSync) {
                    // Same direction or low mandatory desire
                    thetaLeft = 1;
                } else if (dLeftRoute*(dLeftSpeed+dLeftBias)<0 && 
                        dSync<Math.abs(dLeftRoute) && Math.abs(dLeftRoute)<dCoop) {
                    // Voluntary incentives paritally included
                    thetaLeft = (dCoop-Math.abs(dLeftRoute)) / (dCoop-dSync);
                }
                dLeft = dLeftRoute + thetaLeft*(dLeftSpeed+dLeftBias);
                // Idem. for right
                double thetaRight = 0;
                if (dRightRoute*(dRightSpeed+dRightBias)>=0 || Math.abs(dRightRoute)<=dSync) {
                    thetaRight = 1;
                } else if (dRightRoute*(dRightSpeed+dRightBias)<0 &&
                        dSync<Math.abs(dRightRoute) && Math.abs(dRightRoute)<dCoop) {
                    thetaRight = (dCoop-Math.abs(dRightRoute)) / (dCoop-dSync);
                }
                dRight = dRightRoute + thetaRight*(dRightSpeed+dRightBias);

                /* === GAP ACCEPTANCE ===
                 * A gap is accepted or rejected based on the resulting
                 * acceleration of the driver itself and the potential follower.
                 */
                // Determine own acceleration
                double aSelf = 0; // assume ok
                if (vehicle.leftDown!=null && vehicle.getHeadway(vehicle.leftDown)>0) {
                    // Use car-following model
                    setT(dLeft);
                    aSelf = calculateAcceleration(vehicle, vehicle.leftDown);
                    resetT();
                } else if (vehicle.leftDown!=null) {
                    // Negative headway, reject gap
                    aSelf = Double.NEGATIVE_INFINITY;
                }
                // Determine follower acceleration
                double aFollow = 0; // assume ok
                if (vehicle.leftUp != null) {
                    if (vehicle.leftUp.getHeadway(vehicle)>0) {
                        vehicle.leftUp.getDriver().setT(dLeft);
                        aFollow = calculateAcceleration(vehicle.leftUp, vehicle);
                        vehicle.leftUp.getDriver().resetT();
                    } else {
                        aFollow = Double.NEGATIVE_INFINITY;
                    }
                }
                /* The gap is accepted if both accelerations are larger than a
                 * desire depedant threshold.
                 */
                boolean acceptLeft = false;
                if (aSelf >= -bSafe*dLeft && aFollow >= -bSafe*dLeft && vehicle.lane.goLeft) {
                    acceptLeft = true;
                }
                // Idem. for right gap
                aSelf = 0;
                if (vehicle.rightDown!=null && vehicle.getHeadway(vehicle.rightDown)>0) {
                    setT(dRight);
                    aSelf = calculateAcceleration(vehicle, vehicle.rightDown);
                    resetT();
                } else if (vehicle.rightDown!=null) {
                    aSelf = Double.NEGATIVE_INFINITY;
                }
                aFollow = 0;
                if (vehicle.rightUp != null) {
                    if (vehicle.rightUp.getHeadway(vehicle)>0) {
                        vehicle.rightUp.getDriver().setT(dRight);
                        aFollow = calculateAcceleration(vehicle.rightUp, vehicle);
                        vehicle.rightUp.getDriver().resetT();
                    } else {
                        aFollow = Double.NEGATIVE_INFINITY;
                    }
                }
                boolean acceptRight = false;
                if (aSelf >= -bSafe*dRight && aFollow >= -bSafe*dRight && vehicle.lane.goRight) {
                    acceptRight = true;
                }

                /* LANE CHANGE DECISION
                 * A lane change is initiated towards the largest desire if that
                 * gap is accepted. If the gap is rejected, the turn indicator 
                 * may be turned on.
                 */
                if (dLeft>=dRight && dLeft>=dFree && acceptLeft) {
                    // Set dy to the left
                    double dur = Math.min((vehicle.route.xLaneChanges(vehicle.lane)-vehicle.x)/(180/3.6), duration);
                    vehicle.changeLeft(vehicle.model.dt/dur);
                    // Set headway
                    setT(dLeft);
                    // Set response headway of new follower
                    if (vehicle.leftUp != null && vehicle.leftUp.rightDown==vehicle) {
                        vehicle.leftUp.getDriver().setT(dLeft);
                    }
                } else if (dRight>=dLeft && dRight>=dFree && acceptRight) {
                    // Set dy to the right
                    double dur = Math.min((vehicle.route.xLaneChanges(vehicle.lane)-vehicle.x)/(180/3.6), duration);
                    vehicle.changeRight(vehicle.model.dt/dur);
                    // Set headway
                    setT(dRight);
                    if (vehicle.rightUp != null && vehicle.rightUp.leftDown==vehicle) {
                        vehicle.rightUp.getDriver().setT(dRight);
                    }
                } else if (dLeft>=dRight && dLeft>=dCoop) {
                    // Indicate need to left
                    vehicle.leftIndicator = true;
                } else if (dRight>=dLeft && dRight>=dCoop) {
                    // Indicate need to right
                    vehicle.rightIndicator = true;
                }
            } // not on first 100m
            
            /* === LONGITUDINAL ===
             * Follow all applicable vehicles and use lowest acceleration.
             */
            // Follow leader (regular car following)
            lowerAcceleration(calculateAcceleration(vehicle, vehicle.down));
            // Synchronize to perform a lane change
            if (dLeft>=dSync && dLeft>=dRight && vehicle.leftDown!=null && vehicle.leftDown.v-5/3.6<vehicle.v) {
                // Apply shorter headway for synchronization
                setT(dLeft);
                lowerAcceleration(safe(calculateAcceleration(vehicle, vehicle.leftDown)));
                resetT();
                leftSync = true;
            } else if (dRight>=dSync && dRight>dLeft && vehicle.rightDown!=null && vehicle.rightDown.v-5/3.6<vehicle.v) {
                // Apply shorter headway for synchronization
                setT(dRight);
                lowerAcceleration(safe(calculateAcceleration(vehicle, vehicle.rightDown)));
                resetT();
                rightSync = true;
            }
            // Synchronize to create a gap
            if (vehicle.leftDown!=null && vehicle.leftDown.rightUp==vehicle &&
                    vehicle.leftDown.rightIndicator) {
                // Apply shorter headway for gap-creation
                setT(vehicle.leftDown.getDriver().dRight);
                lowerAcceleration(safe(calculateAcceleration(vehicle, vehicle.leftDown)));
                resetT();
                rightYield = true; // deals with right lane change of other
            }
            if (vehicle.rightDown!=null && vehicle.rightDown.leftUp==vehicle &&
                    vehicle.rightDown.leftIndicator) {
                // Apply shorter headway for gap-creation
                setT(vehicle.rightDown.getDriver().dLeft);
                lowerAcceleration(safe(calculateAcceleration(vehicle, vehicle.rightDown)));
                resetT();
                leftYield = true; // deals with left lane change of other
            }

        } else {

            // Performing a lane change, simply follow both leaders
            lowerAcceleration(calculateAcceleration(vehicle, vehicle.down));
            lowerAcceleration(calculateAcceleration(vehicle, vehicle.lcVehicle.down));
        }
    }
    
    /**
     * Sets the acceleration of the vehicle only if the given value is lower 
     * than the current value or in case of a new time step.
     * @param a Vehicle acceleration [m/s^2].
     */
    public void lowerAcceleration(double a) {
        if (a<vehicle.a || tAccLower<vehicle.model.t) {
            vehicle.a = a;
            tAccLower = vehicle.model.t;
        }
    }
    
    /**
     * Returns a limited value of acceleration which remains comfortable and 
     * safe according to a >= -bSafe. This limit can be used for synchronization
     * with an adjacent lane and not for car-following as 'safe' does not mean
     * collision free, but safe with regard to upsteram followers.
     * @param a Acceleration as calculated for an adjacent leader [m/s^2].
     * @return Limited safe acceleration [m/s^2].
     */
    public double safe(double a) {
        return a >= -bSafe ? a : -bSafe;
    }

    /**
     * Return the current value of the internal use headway value [s].
     * @return Current value of the internal use headway value [s].
     */
    public double T() {
        return T;
    }
    
    /**
     * Sets T depending on the level of lane change desire. This method will
     * never increase the current T value. Lane change desire may be of another
     * driver. If the T value is only set for an evaluation that does not result
     * in an actual action, the value for T should be reset using
     * <code>resetT()</code>. If one calls this method consequentially without
     * calling the reset method in between, the regular car following headway
     * becomes lost.
     * @param d Desire for lane change.
     */
    public void setT(double d) {
        Ttmp = T;
        if (d>0 && d<1) {
            double Tint = d*Tmin + (1-d)*Tmax;
            T = T <= Tint ? T : Tint;
        } else if (d<=0) {
            T = T <= Tmax ? T : Tmax;
        } else {
            T = T <= Tmin ? T : Tmin;
        }
    }

    /**
     * Resets the T value to regular car-following. The T value for this is
     * stored when <code>setT(d)</code> is called.
     */
    public void resetT() {
        T = Ttmp;
    }

    /**
     * Returns an anticipated speed based on the speed limit, maximum vehicle
     * speed and the speed of leaders. Vehicles on adjacent lanes with 
     * indicators turned on towards the lane are also considered. Internal
     * bookkeeping prevents multiple loops over leading vehicles on any
     * particular lane by storing the anticipation speed for adjacent lanes.
     * @param lane Lane at which an aticipated speed is required.
     * @return Anticipated speed on lanes [left, current, right].
     */
    protected double anticipatedSpeed(jLane lane) {
        if (lane==null) {
            return 0;
        }
        // Be sure we exclude the vehicle itself
        double x = vehicle.x+0.001;
        // In case of an adjacent lane, get the adjacent x
        if (lane!=vehicle.lane) {
            if (lane.right!=null && lane.right==vehicle.lane) {
                x = vehicle.getAdjacentX(jModel.latDirection.LEFT); // lane = left lane of vehicle
            } else {
                x = vehicle.getAdjacentX(jModel.latDirection.RIGHT); // lane = right lane of vehicle
            }
        }
        // Clear bookkeeping in case of new time step
        if (tAnt<lane.model.t) {
            antFromLeft.clear();
            antInLane.clear();
            antFromRight.clear();
            tAnt = lane.model.t;
        }
        // Initialize as infinite
        double vLeft = Double.POSITIVE_INFINITY;
        double vCur = Double.POSITIVE_INFINITY;
        double vRight = Double.POSITIVE_INFINITY;
        // Calculate anticipation speed in current lane
        if (!antInLane.containsKey(lane)) {
            anticipatedSpeedFromLane(lane, x);
        }
        vCur = antInLane.get(lane); // all in lane
        // Calculate anticipation speed in left lane
        if (lane.left!=null) {
            if (!antFromLeft.containsKey(lane)) {
                double xleft = lane.getAdjacentX(x, jModel.latDirection.LEFT);
                anticipatedSpeedFromLane(lane.left, xleft);
            }
            vLeft = antFromLeft.get(lane); // indicators only
        }
        // Calculate anticipation speed in right lane
        if (lane.right!=null) {
            if (!antFromRight.containsKey(lane)) {
                double xright = lane.getAdjacentX(x, jModel.latDirection.RIGHT);
                anticipatedSpeedFromLane(lane.right, xright);
            }
            vRight = antFromRight.get(lane); // indicators only
        }
        // Return minimum of all
        return Math.min(vCur, Math.min(vLeft, vRight));
    }

    /**
     * Supporting method that loops all leaders in a lane and calculates their
     * influence on the given and adjacent lanes, where only vehicles with
     * indicators turned on are considered for the adjacent lanes. This method
     * stores the information for up to three lanes, preventing multiple loops
     * over the leaders in the requested lane. These speeds can be retreived
     * from the hashmaps <code>antFromLeft</code>, <code>antInLane</code> and
     * <code>antFromRight</code> by using their <code>.get(jLane)</code> method
     * where the lane is the lane for which the anticipation speed is required.
     * @param lane Requested lane of influence on this or an adjacent lane.
     * @param x Location on the lane.
     */
    protected void anticipatedSpeedFromLane(jLane lane, double x) {
        // Initialize as desired velocity (= no influence).
        double vLeft = desiredVelocity();
        double vCur = desiredVelocity();
        double vRight = desiredVelocity();
        // Find first leader
        jMovable down = lane.findVehicle(x, jModel.longDirection.DOWN);
        double s = 0;
        double v = 0;
        // Loop leaders while within anticipation region
        while (down!=null && s<=x0) {
            // interpolate from "v(s=x0) = vDes" to "v(s=0) = down.v" e.g.
            // with headway = 0 take vehicle fully into account, and with
            // headway > x0 ignore vehicle, in between interpolate linearly
            s = down.x+lane.xAdj(down.lane) - down.l - x;
            // only consider if new headway is within consideration range and
            // speed is below the desired speed, otherwise there is no influence
            if (s<=x0 && down.v<desiredVelocity()) {
                // influence of a single vehicle
                v = anticipateSingle(s, down.v);
                // take minimum
                vCur = Math.min(vCur, v);
                /* Indicators from the current lane are not included for the
                 * anticipated speeds of the adjacent lanes. This is to prevent
                 * a slow queue adjacent to an empty lane, where the anticipated
                 * speeds are then consequently low.
                 */
                if (down.leftIndicator && lane!=vehicle.lane) {
                    vLeft = Math.min(vLeft, v);
                } else if (down.rightIndicator && lane!=vehicle.lane) {
                    vRight = Math.min(vRight, v);
                }
                /* MODEL ERROR!
                 * lane!=vehicle.lane does not cover vehicles that are in any
                 * downstream lane. These should also be ignored! For now
                 * (17-08-2011) this will remain as paper with this model has
                 * been submitted. The if statements should include:
                 *  && vehicle.lane.xAdj(lane)==0
                 */
            }
            // go to next vehicle
            down = down.down;
        }
        // store anticipated speeds
        if (lane.right!=null) {
            antFromLeft.put(lane.right, vRight); // this lane is the left lane of lane.right
        }
        antInLane.put(lane, vCur);
        if (lane.left!=null) {
            antFromRight.put(lane.left, vLeft); // this lane is the right lane of lane.left
        }
    }

    /**
     * Supporting method to return the influence of a single vehicle on the
     * anticipated speed.
     * @param s Headway [m]
     * @param v Speed [m/s]
     * @return Anticipation speed of a single vehicle [m/s]
     */
    protected double anticipateSingle(double s, double v) {
        return (1-(s/x0))*v + (s/x0)*desiredVelocity();
    }

    /**
     * Determine acceleration based on specific vehicle. If this has been
     * calculated this time step, take previously calculated value. Stored
     * accelerations are automatically cleared each time step. This is useful if
     * acceleration between a set of vehicles is needed multiple times within
     * each time step. Otherwise one should circumvent the look-up and store
     * procedure by directly using <code>calculateAcceleration()</code>. Note
     * that by supplying a follower, the <code>getAcceleration()</code> will be
     * called on the correct driver, which may be different from the original
     * driver on which it is called.
     * @param follower Vehicle whos acceleration is required.
     * @param leader Acceleration is based on this vehicle.
     * @return Acceleration [m/s^2].
     */
    public double getAcceleration(jMovable follower, jMovable leader) {
        // default: without type label
        return getAcceleration(follower, leader, "");
    }
    
    /**
     * Determine acceleration based on specific vehicle and label. If this has
     * been calculated this time step, take previously calculated value. Stored
     * accelerations are automatically cleared each time step. The label can be
     * used to distinct between different acceleration types when storing or
     * retreiving them from memory. Note that to calculate actual different
     * values, parameters need to be set before <code>getAcceleration()</code>
     * is called. Note that by supplying a follower, the <code>getAcceleration()
     * </code> will be called on the correct driver, which may be different from
     * the original driver on which it is called.
     * @param follower Vehicle of considered driver.
     * @param leader Acceleration is based on this vehicle.
     * @param label Label for type of acceleration (e.g. following, lane change)
     * used for storage.
     * @return Acceleration [m/s^2].
     */
    public double getAcceleration(jMovable follower, jMovable leader, java.lang.String label) {
        double acc = 0;
        if (follower.getDriver()==this || (vehicle.lcProgress!=0 && follower==vehicle.lcVehicle)) {
            // reset stored accelerations each time step
            if (vehicle.model.t > tAcc) {
                tAcc = vehicle.model.t;
                accelerations.clear();
            }
            if (!vehicle.model.isGenerating() && accelerations.containsKey(leader) && accelerations.get(leader).containsKey(label)) {
                // get acceleration that has allready been calculated
                acc = accelerations.get(leader).get(label);
            } else if (vehicle.model.isGenerating()) {
                // calculate and do not store acceleration as vehicle generation
                // may just be testing the current location
                acc = calculateAcceleration(leader);
            } else {
                // calculate and store acceleration
                acc = calculateAcceleration(leader);
                if (accelerations.containsKey(leader)) {
                    accelerations.get(leader).put(label, acc); // may include 'null' as leader
                } else {
                    java.util.HashMap<java.lang.String, Double> submap =
                            new java.util.HashMap<java.lang.String, Double>();
                    submap.put(label, acc);
                    accelerations.put(leader, submap);
                }
             }
        } else {
            // acceleration from other vehicle, find correct driver
            if (follower.getDriver()==null) {
                System.err.println("No driver: "+follower.x+"@"+follower.lane.id+" - "+leader.x+"@"+leader.lane.id);
            }
            acc = follower.getDriver().getAcceleration(follower, leader);
        }
        return acc;
    }

    /**
     * Same as <code>calculateAcceleration()</code> with single input. This
     * method additionally searches for the correct driver in the following
     * vehicle.
     * @param follower Vehicle of considered driver.
     * @param leader Acceleration is based on this vehicle.
     * @return Acceleration [ms/^2].
     */
    public double calculateAcceleration(jMovable follower, jMovable leader) {
        return follower.getDriver().calculateAcceleration(leader);
    }
    
    /**
     * Calculation of acceleration based on a specific leader. The default is
     * the IDM+ car following model.
     * @param leader Acceleration is based on this vehicle.
     * @return Acceleration [m/s^2].
     */
    public double calculateAcceleration(jMovable leader) {
        // Longitudinal model
        // get input
        double v = vehicle.v; // own speed [m/s]
        double s; // net headway [m]
        double dv; // speed difference [m/s]
        double v0 = desiredVelocity();
        if (leader!=null) {
            s = vehicle.getHeadway(leader);
            dv = v-leader.v;
        } else {
            s = Double.POSITIVE_INFINITY;
            dv = 0;
        }
        double acc = 0;
        // calculate acceleration
        acc = IDM(v, dv, v0, s);
        // limit acceleration
        acc = Math.max(acc, vehicle.aMin);
        return acc;
    }

    /**
     * Calculates the acceleration towards an object.
     * @param v Own velocity.
     * @param dv Velocity difference with object.
     * @param v0 Desired velocity.
     * @param s Distance to object.
     * @return Acceleration towards object.
     */
    public double IDM(double v, double dv, double v0, double s) {
        double ss = desiredEquilibriumHeadway()+(v*dv)/(2*Math.sqrt(a*b)); // dynamic desired gap
        /* Because of the power of 2, the IDM inteprets a negative sign of
         * either s and ss as positive. In all cases this makes no sense.
         */
        ss = Math.max(ss, 0);
        s = Math.max(s, 1e-99); // no division by zero 
        return a*Math.min(1-Math.pow((v/v0),4), 1-Math.pow((ss/s),2));
    }

    /**
     * The desired headway method returns the desired <b>equilibrium</b> net
     * headway. It is used by the vehicle generator, and possibly the driver
     * itself.
     * @return Desired net headway [m]
     */
    public double desiredEquilibriumHeadway() {
        double v = vehicle.v;
        return s0 + v*T;
    }

    /**
     * This method returns the desired speed on the current lane. It is used by
     * the vehicle generator, and possibly the driver itself.
     * @return Desired velocity [m/s]
     */
    public double desiredVelocity() {
        if (vehicle.model.t!=vDesT) {
            vDes = Math.min(vehicle.getVMax(), fSpeed*vehicle.lane.getVLim());
            vDesT = vehicle.model.t;
        }
        return vDes;
    }
    
    /**
     * This method calls <tt>notice(jRSU)</tt> on all noticable RSUs within the 
     * range <code>noticeableRange</code>.
     */
    public void noticeRSUs() {
        jRSU lastRSU = null;
        double xLast = vehicle.x;
        double range = noticeableRange;
        while (range>0) {
            lastRSU = vehicle.lane.findNoticeableRSU(xLast, range);
            if (lastRSU==null) {
                range = -1;
            } else {
                notice(lastRSU);
                range = noticeableRange - vehicle.getDistanceToRSU(lastRSU);
                xLast = vehicle.lane.xAdj(lastRSU.lane)+lastRSU.x;
            }
        }
    }

    /**
     * Drivers may notice a RSU. For each specific type, a <code>notice(type)
     * </code> method should be created. The <code>rsu.isNoticed()</code> lets
     * the driver notice the specific RSU type. This method should be used as a
     * forward to the correct <tt>notice</tt> method.
     * @param rsu Noticed RSU.
     */
    public final void notice(jRSU rsu) {
        if (inGeneralNotice) {
            // Method got called in a loop.
            String cls = rsu.getClass().getName();
            System.err.println("Please provide a 'notice("+cls+")' method in your driver class.");
        } else {
            inGeneralNotice = true;
            rsu.isNoticed(this);
            inGeneralNotice = false;
        }
    }

    /**
     * Sets deceleration for a traffic light, if needed.
     * @param trafficLight Traffic light that was noticed.
     */
    public void notice(jTrafficLight trafficLight) {
        double v = vehicle.v;
        double dv = v; // stand still object
        double v0 = vehicle.lane.getVLim();
        double s = vehicle.getDistanceToRSU(trafficLight);
        if (trafficLight.isRed()) {
            double acc = IDM(v, dv, v0, s);
            if (acc>-bRed) {
                lowerAcceleration(acc);
            }
        } else if (trafficLight.isYellow()) {
            double acc = IDM(v, dv, v0, s);
            if (acc>-b) { // yellow acceptance by -b [m/s2]
                lowerAcceleration(acc);
            }
        }
    }

    /**
     * Is called once at vehicle generation <i>after</i> the stochastic
     * vehicle and driver parameters have been set. It can be used to define
     * parameter correlations.
     */
    public void correlateParameters() {
        T = Tmax;
    }

    /**
     * Whether the driver is on a taper lane <i>that is applicable</i> to this 
     * driver.
     * @return Whether the driver is on a taper lane.
     */
    public boolean isOnTaper() {
        return isTaper(vehicle.lane);
    }

    /**
     * Same as isOnTaper(), but if the vehicle would be on the given lane.
     * @param lane Lane for which it needs to be known whether it is an applicable taper.
     * @return Whether lane is an applicable taper to this driver.
     */
    public boolean isTaper(jLane lane) {
        return (lane.taper!=null && vehicle.route.canBeFollowedFrom(lane.taper));
    }
}