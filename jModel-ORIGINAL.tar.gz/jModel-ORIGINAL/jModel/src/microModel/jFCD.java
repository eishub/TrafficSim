package microModel;

/**
 * Snapshot of vehicle state. A series of snapshots can be used as a trajectory  
 * or floating car data.
 */
public class jFCD {

    /** Time of snapshot. */
    public double t;

    /** Position of vehicle on the lane. */
    public double x;

    /** Speed of  vehicle [m/s]. */
    public double v;

    /** Acceleration of vehicle [m/s^2]. */
    public double a;

    /** Lane at which the vehicle is. */
    public jLane lane;

    /** Lane changing progress of vehicle, including direction [-1...1]. */
    public double lcProgress;

    /**
     * Constructs a snapshot of the given vehicle.
     * @param veh
     */
    public jFCD(jVehicle veh) {
        t = veh.model.t;
        x = veh.x;
        v = veh.v;
        a = veh.a;
        lane = veh.lane;
        if (veh.lcDirection==jModel.latDirection.LEFT) {
            lcProgress = -veh.lcProgress; // [-1...0]
        } else {
            lcProgress = veh.lcProgress; // [0...1]
        }
    }
}